// Reports.h - dashboard statistics and reports with CSV export (Modules 8 and 10)
#pragma once
#include "Database.h"

namespace Reports {
json dashboard(Database& db);                                  // everything the web dashboard shows
json byType(Database& db, const std::string& type);            // events|sessions|topics|rooms|duplicates|capacity|attendance
json attendeeHistory(Database& db, int attendeeId);            // one attendee's sessions
std::string toCsv(const json& rows);                           // array of flat objects -> CSV text
}
