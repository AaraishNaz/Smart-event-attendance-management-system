#include "Pipeline.h"
#include <memory>

Pipeline::Pipeline(std::string dbPath, int workers) : dbPath_(std::move(dbPath)) {
    if (workers < 1) workers = 1;
    for (int i = 0; i < workers; ++i) workers_.emplace_back(&Pipeline::workerLoop, this, i);
}

std::future<ScanOutcome> Pipeline::submit(ScanRequest req) {
    ScanJob job;
    job.req = std::move(req);
    std::future<ScanOutcome> fut = job.result.get_future();
    if (!queue_.push(std::move(job))) {          // queue closed: job was NOT consumed, answer immediately
        ScanOutcome o;
        o.result = CheckInResult::DATABASE_ERROR;
        o.message = "Server is shutting down - scan not accepted";
        job.result.set_value(std::move(o));
    }
    return fut;
}

void Pipeline::workerLoop(int /*id*/) {
    std::unique_ptr<Database> db;                 // this thread's private connection
    try { db = std::make_unique<Database>(dbPath_); } catch (const std::exception&) {}
    ScanJob job;
    while (queue_.pop(job)) {                     // false only when closed AND empty
        ScanOutcome o;
        try {
            if (!db) throw DbError("worker has no database connection", -1);
            o = AttendanceEngine::checkIn(*db, job.req);
        } catch (const std::exception& e) {
            o.result = CheckInResult::DATABASE_ERROR;
            o.message = e.what();
        }
        counts_[static_cast<int>(o.result)]++;
        processed_++;
        job.result.set_value(std::move(o));       // wakes the producer waiting on the future
    }
}

void Pipeline::shutdown() {
    queue_.close();
    for (auto& t : workers_) if (t.joinable()) t.join();
}

json Pipeline::stats() const {
    json j;
    j["workers"] = workers_.size();
    j["queue_length"] = queue_.size();
    j["processed"] = processed_.load();
    for (int i = 0; i < 6; ++i) j["by_result"][toString(static_cast<CheckInResult>(i))] = counts_[i].load();
    return j;
}
