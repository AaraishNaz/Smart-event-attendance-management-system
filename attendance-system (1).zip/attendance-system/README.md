# Smart Event Attendance Management System (During the Event)

Team **Coderssss** - B.Tech CSE Project-Based Learning, Phase 3.
Per-session check-in kiosks, a multithreaded C++17 attendance engine, SQLite storage, a REST API and a live web dashboard.

## 1. Build & run (Windows 10/11, VS Code, MinGW-w64, CMake)

Requirements: MinGW-w64 g++ (MSYS2 **UCRT64** or WinLibs, *posix threads* variant), CMake 3.18+, internet on the **first** configure.

```bat
build.bat                      :: configures + compiles (downloads httplib, nlohmann/json, SQLite once)
build\run_tests.exe            :: unit tests, concurrency demo, 4 stress workloads
build\attendance_server.exe    :: starts the server  ->  open http://localhost:8080
```
Linux/macOS: `./build.sh`, then `./build/run_tests` and `./build/attendance_server`.

Server options: `--port 8080 --db attendance.db --workers 4 --host 127.0.0.1 --web path/to/web`.
On first start the database is created and seeded (1 demo event, 4 topics, 6 sessions, four named student accounts, one overlapping class slot, and an initial audit scan).
Delete `attendance.db` to start fresh.

### Manual dependency download (only if CMake cannot download)
Put these files into `third_party/`:

| file | source |
|---|---|
| `httplib.h` | cpp-httplib v0.15.3 - `https://raw.githubusercontent.com/yhirose/cpp-httplib/v0.15.3/httplib.h` |
| `nlohmann/json.hpp` | `https://github.com/nlohmann/json/releases/download/v3.11.3/json.hpp` |
| `sqlite3.c`, `sqlite3.h` | SQLite amalgamation 3.46.0 - `https://www.sqlite.org/2024/sqlite-amalgamation-3460000.zip` |

## 2. GEHU demo logins

The first database initialization creates these local demonstration accounts:

| Role | Username | Password |
|---|---|---|
| Student | `aaraish` | `Student@123` |
| Student | `apoorva` | `Student@123` |
| Student | `harsh` | `Student@123` |
| Student | `aditi` | `Student@123` |
| Teacher | `teacher` | `Teacher@123` |
| Event organizer | `organizer` | `Organizer@123` |
| Administrator | `admin` | `Admin@123` |

Sample student records are Aaraish Naz, Apoorva Singh, Harsh Tanwar and Aditi Mamgain. These are demo credentials only; change them before any real deployment. Passwords are stored as PBKDF2-HMAC-SHA256 hashes (120,000 iterations) on Windows. Login sessions use random tokens in HttpOnly, SameSite cookies and expire after eight hours. For a real deployment, use HTTPS (and add the Secure cookie attribute), rate limiting, CSRF protection, institution-managed identity, backups and security review. This localhost demo is not an approved GEHU ERP integration.

## 3. New feature workflow

1. Organizer signs in and creates an event. New events enter `PENDING` approval state.
2. Administrator signs in, opens **Event Approvals**, and approves the event.
3. Organizer opens **Live QR Display**, chooses a session and projects the changing QR. Each challenge expires after three seconds.
4. Student signs in, scans the QR using a supported browser camera or pastes the current token, and submits it. The server validates login, event approval, session, token expiry, duplicate attendance and capacity.
5. On a successful event check-in, any overlapping scheduled class for the student's demo batch is marked `PRESENT_VIA_APPROVED_EVENT`. The class record references the approved event; it does not claim the student was physically in the classroom.
6. Teacher can inspect attendance timestamps and the class-attendance synchronization audit.

A three-second rotating QR makes saved screenshots quickly expire, but cannot fully prevent live relaying or someone sharing a QR within its short validity window. Stronger production controls would include device binding, location/network policy, organizer-side monitoring and a verified ERP integration.

## 4. Folder structure
```
CMakeLists.txt  build.bat  build.sh  README.md
src/    Database.*  Models.*  Schema.*  Repository.*  AttendanceEngine.*  Auth.*  ScanQueue.h  Pipeline.*
        Reports.*  Workload.*  main.cpp
web/    index.html  style.css  app.js
tests/  tests.cpp
docs/   EXPLAIN.md   <- architecture + demo script + viva questions
```

## 5. Modules -> files
| # | Module | Files |
|---|---|---|
| 1 | Database management | `Database.*` (connection, transactions), `Schema.cpp` (tables, indexes, view, seed, integrity check) |
| 2 | Attendees | `Models.*`, `Repository.cpp` (register, unique ID + QR id, search, update, delete) |
| 3 | Events | `Repository.cpp` (events + topics) |
| 4 | Sessions | `Repository.cpp` (rooms, topics, timings, capacity, occupancy, room-overlap check) |
| 5 | QR / ID check-in | `AttendanceEngine.*` |
| 6 | Multithreading | `ScanQueue.h`, `Pipeline.*` |
| 7 | Capacity enforcement | `AttendanceEngine.cpp` (`BEGIN IMMEDIATE` transaction) |
| 8 | Web dashboard | `web/*`, `Reports::dashboard` |
| 9 | REST API | `main.cpp` |
| 10 | Reports + CSV | `Reports.*` |
| 11 | Concurrency demo | `Workload.cpp` (`runConcurrencyDemo`) + "Concurrency Lab" page |
| 12 | Tests & performance | `tests/tests.cpp`, `Workload.cpp` (`runStressSuite`) |

## 6. REST API
| Method | Path | Purpose |
|---|---|---|
| POST | `/api/auth/login`, `/api/auth/logout` | role-based sign-in and sign-out |
| GET | `/api/auth/me` | current signed-in user |
| GET | `/api/my/attendance` | student's event and class attendance |
| GET | `/api/dashboard` | dashboard numbers |
| GET/POST | `/api/events` | list / create (optional `topics: []`) |
| GET/PUT/DELETE | `/api/events/{id}` | details (with topics + sessions) / update / delete* |
| POST | `/api/events/{id}/topics` | add topic |
| GET / DELETE | `/api/topics?event_id=` , `/api/topics/{id}` | list / delete topic |
| GET/POST | `/api/sessions?event_id=` | list (with occupancy) / create |
| GET/PUT/DELETE | `/api/sessions/{id}` | view / update / delete* |
| GET/POST | `/api/attendees?q=` | search / register |
| GET/PUT/DELETE | `/api/attendees/{id}` | view / update / delete* |
| GET | `/api/attendees/{id}/history` | attendance history |
| GET | `/api/attendance?session_id=&attendee_id=&limit=` | attendance log |
| POST | `/api/checkin` | staff/kiosk check-in by attendee ID or attendee QR |
| GET | `/api/sessions/{id}/qr-token` | organizer/admin: create a 3-second rotating challenge |
| POST | `/api/event-checkin` | student: validate current event QR and record attendance |
| GET | `/api/approvals/pending` | administrator: pending event approvals |
| POST | `/api/events/{id}/approve` | administrator: approve event |
| GET | `/api/class-attendance` | teacher/admin class synchronization audit |
| GET | `/api/reports/{events,sessions,topics,rooms,capacity,duplicates,attendance}[?format=csv]` | reports |
| GET | `/api/integrity`, `/api/health` | integrity check, pipeline counters |
| POST | `/api/demo/concurrency`, `/api/demo/stress` | concurrency lab (disposable DBs) |

\* deletion is refused with **409** when attendance records exist ("delete where appropriate").
Status codes: 200/201 OK, 400 validation/role denial, 401 unauthenticated, 403 forbidden, 404 not found, 409 conflict/expired QR, 500 database error.
`POST /api/checkin` maps results: SUCCESS 201, DUPLICATE 409, SESSION_FULL 409, UNKNOWN_* 404, DATABASE_ERROR 500.

Example:
```
curl -X POST localhost:8080/api/checkin -H "Content-Type: application/json" -d "{\"code\":\"ATT-0001\",\"session_id\":1,\"kiosk_id\":\"LAB1\"}"
```

## 5. Honest notes
* Scanning = USB scanner acting as a keyboard, or manual ID entry. **Camera-based QR scanning is not implemented.**
* One extra table, `scan_log`, records every scan (also rejected ones) - that is what makes duplicate statistics real.
* Attendees are registered globally (the required 5 tables have no event-attendee link); "attendance %" per event = distinct attendees who checked in / registered attendees.
* The unsafe demo is timing dependent: its numbers differ from run to run (it only runs on disposable databases).
