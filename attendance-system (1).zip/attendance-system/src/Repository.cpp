#include "Repository.h"
#include "Schema.h"
#include <chrono>
#include <cstdio>
#include <random>
#include <thread>

namespace {
// Translate low-level SQLite errors into meaningful API errors.
[[noreturn]] void translate(const DbError& e) {
    if ((e.code & 0xFF) == SQLITE_CONSTRAINT) {
        if (e.code == SQLITE_CONSTRAINT_FOREIGNKEY) throw ValidationError("Referenced record does not exist");
        if (e.code == SQLITE_CONSTRAINT_UNIQUE || e.code == SQLITE_CONSTRAINT_PRIMARYKEY)
            throw Conflict("A record with the same unique value already exists");
        throw ValidationError(e.what());
    }
    throw e;
}
template <class F>
auto wrap(F&& f) -> decltype(f()) {
    try { return f(); } catch (const DbError& e) { translate(e); }
}
long long scalar(Database& db, const std::string& sql, const std::vector<json>& p = {}) {
    return db.query(sql, p)[0]["c"].get<long long>();
}
std::string makeQr() {   // unique QR identifier, e.g. QR-9F3A62C01B7D
    thread_local std::mt19937_64 rng(std::random_device{}() ^
        static_cast<unsigned long long>(std::chrono::steady_clock::now().time_since_epoch().count()) ^
        std::hash<std::thread::id>{}(std::this_thread::get_id()));
    static const char* hex = "0123456789ABCDEF";
    std::string s = "QR-";
    for (int i = 0; i < 12; ++i) s += hex[rng() % 16];
    return s;
}
}  // namespace

// ============================ EVENTS ============================
json Repository::createEvent(const json& body) {
    Event e = Event::fromRequest(body);
    long long id = wrap([&] {
        Tx tx(db_);
        db_.run("INSERT INTO events(name,location,start_date,end_date,description) VALUES(?,?,?,?,?)",
                {e.name, e.location, e.startDate, e.endDate, e.description});
        long long newId = db_.lastInsertId();
        for (const auto& t : e.topics) db_.run("INSERT OR IGNORE INTO topics(event_id,name) VALUES(?,?)", {newId, t});
        tx.commit();
        return newId;
    });
    return getEvent(static_cast<int>(id));
}

json Repository::updateEvent(int id, const json& body) {
    Event e = Event::fromRequest(body);
    int n = wrap([&] {
        return db_.run("UPDATE events SET name=?,location=?,start_date=?,end_date=?,description=? WHERE event_id=?",
                       {e.name, e.location, e.startDate, e.endDate, e.description, id});
    });
    if (n == 0) throw NotFound("Event not found");
    return getEvent(id);
}

void Repository::deleteEvent(int id) {
    if (scalar(db_, "SELECT COUNT(*) AS c FROM attendance a JOIN sessions s ON s.session_id=a.session_id WHERE s.event_id=?", {id}) > 0)
        throw Conflict("Event already has attendance records and cannot be deleted");
    if (db_.run("DELETE FROM events WHERE event_id=?", {id}) == 0) throw NotFound("Event not found");
}

json Repository::listEvents() {
    return db_.query(
        "SELECT e.*, "
        "(SELECT COUNT(*) FROM sessions s WHERE s.event_id=e.event_id) AS session_count, "
        "(SELECT GROUP_CONCAT(t.name, ', ') FROM topics t WHERE t.event_id=e.event_id) AS topics, "
        "COALESCE(a.status,'PENDING') AS approval_status "
        "FROM events e LEFT JOIN event_approvals a ON a.event_id=e.event_id ORDER BY e.start_date, e.event_id");
}

json Repository::getEvent(int id) {
    json r = db_.query("SELECT * FROM events WHERE event_id=?", {id});
    if (r.empty()) throw NotFound("Event not found");
    json e = r[0];
    e["topics"] = listTopics(id);
    e["sessions"] = listSessions(id);
    return e;
}

json Repository::addTopic(int eventId, const json& body) {
    std::string name = val::reqStr(body, "name");
    if (scalar(db_, "SELECT COUNT(*) AS c FROM events WHERE event_id=?", {eventId}) == 0) throw NotFound("Event not found");
    wrap([&] { db_.run("INSERT INTO topics(event_id,name) VALUES(?,?)", {eventId, name}); });
    return db_.query("SELECT * FROM topics WHERE topic_id=?", {db_.lastInsertId()})[0];
}

json Repository::listTopics(int eventId) {
    if (eventId) return db_.query("SELECT * FROM topics WHERE event_id=? ORDER BY name", {eventId});
    return db_.query("SELECT t.*, e.name AS event_name FROM topics t JOIN events e ON e.event_id=t.event_id ORDER BY e.event_id, t.name");
}

void Repository::deleteTopic(int id) {   // sessions keep existing: their topic_id becomes NULL
    if (db_.run("DELETE FROM topics WHERE topic_id=?", {id}) == 0) throw NotFound("Topic not found");
}

// ============================ SESSIONS ============================
void Repository::checkSession(const Session& s, int ignoreId) {
    if (scalar(db_, "SELECT COUNT(*) AS c FROM events WHERE event_id=?", {s.eventId}) == 0) throw ValidationError("event_id does not exist");
    if (s.topicId && scalar(db_, "SELECT COUNT(*) AS c FROM topics WHERE topic_id=? AND event_id=?", {s.topicId, s.eventId}) == 0)
        throw ValidationError("topic_id does not belong to this event");
    // two sessions may run at the same time, but not in the same room
    if (scalar(db_, "SELECT COUNT(*) AS c FROM sessions WHERE event_id=? AND room=? AND start_time<? AND end_time>? AND session_id<>?",
               {s.eventId, s.room, s.endTime, s.startTime, ignoreId}) > 0)
        throw Conflict("Room '" + s.room + "' is already booked for an overlapping time");
}

json Repository::createSession(const json& body) {
    Session s = Session::fromRequest(body);
    checkSession(s, 0);
    wrap([&] {
        db_.run("INSERT INTO sessions(event_id,topic_id,title,room,start_time,end_time,capacity) VALUES(?,?,?,?,?,?,?)",
                {s.eventId, s.topicId ? json(s.topicId) : json(nullptr), s.title, s.room, s.startTime, s.endTime, s.capacity});
    });
    return getSession(static_cast<int>(db_.lastInsertId()));
}

json Repository::updateSession(int id, const json& body) {
    Session s = Session::fromRequest(body);
    json cur = getSession(id);
    if (s.capacity < cur["checked_in"].get<int>()) throw Conflict("capacity cannot be lower than the current number of check-ins");
    checkSession(s, id);
    wrap([&] {
        db_.run("UPDATE sessions SET event_id=?,topic_id=?,title=?,room=?,start_time=?,end_time=?,capacity=? WHERE session_id=?",
                {s.eventId, s.topicId ? json(s.topicId) : json(nullptr), s.title, s.room, s.startTime, s.endTime, s.capacity, id});
    });
    return getSession(id);
}

void Repository::deleteSession(int id) {
    if (scalar(db_, "SELECT COUNT(*) AS c FROM attendance WHERE session_id=?", {id}) > 0)
        throw Conflict("Session already has attendance records and cannot be deleted");
    if (db_.run("DELETE FROM sessions WHERE session_id=?", {id}) == 0) throw NotFound("Session not found");
}

json Repository::listSessions(int eventId) {
    std::string sql = SESSION_STATS_SQL;
    if (eventId) sql += " WHERE event_id=?";
    sql += " ORDER BY start_time, session_id";
    return eventId ? db_.query(sql, {eventId}) : db_.query(sql);
}

json Repository::getSession(int id) {
    json r = db_.query(std::string(SESSION_STATS_SQL) + " WHERE session_id=?", {id});
    if (r.empty()) throw NotFound("Session not found");
    return r[0];
}

// ============================ ATTENDEES ============================
json Repository::registerAttendee(const json& body) {
    Attendee a = Attendee::fromRequest(body);
    if (scalar(db_, "SELECT COUNT(*) AS c FROM attendees WHERE email=?", {a.email}) > 0) throw Conflict("This e-mail is already registered");
    std::string qr = makeQr();
    long long id = wrap([&] {
        Tx tx(db_);
        // insert with a temporary code, then derive the readable ID from the generated primary key
        db_.run("INSERT INTO attendees(attendee_code,qr_code,name,email,phone,organization) VALUES(?,?,?,?,?,?)",
                {"TMP-" + qr, qr, a.name, a.email, a.phone, a.organization});
        long long newId = db_.lastInsertId();
        char code[24];
        std::snprintf(code, sizeof code, "ATT-%04lld", newId);
        db_.run("UPDATE attendees SET attendee_code=? WHERE attendee_id=?", {std::string(code), newId});
        tx.commit();
        return newId;
    });
    return getAttendee(static_cast<int>(id));
}

json Repository::updateAttendee(int id, const json& body) {
    Attendee a = Attendee::fromRequest(body);
    int n = wrap([&] {
        return db_.run("UPDATE attendees SET name=?,email=?,phone=?,organization=? WHERE attendee_id=?",
                       {a.name, a.email, a.phone, a.organization, id});
    });
    if (n == 0) throw NotFound("Attendee not found");
    return getAttendee(id);
}

void Repository::deleteAttendee(int id) {
    if (scalar(db_, "SELECT COUNT(*) AS c FROM attendance WHERE attendee_id=?", {id}) > 0)
        throw Conflict("Attendee has attendance records and cannot be deleted");
    if (db_.run("DELETE FROM attendees WHERE attendee_id=?", {id}) == 0) throw NotFound("Attendee not found");
}

json Repository::listAttendees(const std::string& search) {
    std::string like = "%" + search + "%";
    return db_.query(
        "SELECT a.*, (SELECT COUNT(*) FROM attendance x WHERE x.attendee_id=a.attendee_id) AS sessions_attended "
        "FROM attendees a WHERE a.name LIKE ?1 OR a.email LIKE ?1 OR a.attendee_code LIKE ?1 OR a.organization LIKE ?1 "
        "ORDER BY a.attendee_id LIMIT 5000", {like});
}

json Repository::getAttendee(int id) {
    json r = db_.query("SELECT * FROM attendees WHERE attendee_id=?", {id});
    if (r.empty()) throw NotFound("Attendee not found");
    return r[0];
}

// ============================ ATTENDANCE LOG ============================
json Repository::listAttendance(int sessionId, int attendeeId, int limit) {
    if (limit < 1 || limit > 5000) limit = 500;
    return db_.query(
        "SELECT a.attendance_id, a.checkin_time, a.kiosk_id, p.attendee_id, p.attendee_code, p.name AS attendee_name, "
        "s.session_id, s.title AS session_title, s.room, e.name AS event_name "
        "FROM attendance a JOIN attendees p ON p.attendee_id=a.attendee_id "
        "JOIN sessions s ON s.session_id=a.session_id JOIN events e ON e.event_id=s.event_id "
        "WHERE (?1=0 OR a.session_id=?1) AND (?2=0 OR a.attendee_id=?2) ORDER BY a.attendance_id DESC LIMIT ?3",
        {sessionId, attendeeId, limit});
}
