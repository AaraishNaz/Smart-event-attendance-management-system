// ScanQueue.h - thread-safe blocking queue (the "shared component" of producer-consumer, Module 6)
//
//   producers (kiosks)  --push-->  [ mutex + condition_variable + std::queue ]  --pop-->  consumers (workers)
//
// close(): no more pushes are accepted, but pop() keeps returning the remaining items (DRAIN).
// pop() returns false only when the queue is closed AND empty -> workers can exit safely, no scan is lost.
#pragma once
#include <condition_variable>
#include <cstddef>
#include <mutex>
#include <queue>
#include <utility>

template <typename T>
class ScanQueue {
public:
    // Returns false (and leaves 'item' untouched) if the queue is already closed.
    bool push(T&& item) {
        {
            std::unique_lock<std::mutex> lk(m_);
            if (closed_) return false;
            q_.push(std::move(item));
        }
        cv_.notify_one();          // wake exactly one sleeping consumer
        return true;
    }

    // Blocks while the queue is empty and still open.
    bool pop(T& out) {
        std::unique_lock<std::mutex> lk(m_);
        cv_.wait(lk, [this] { return !q_.empty() || closed_; });   // loop protects against spurious wake-ups
        if (q_.empty()) return false;                              // closed and drained
        out = std::move(q_.front());
        q_.pop();
        return true;
    }

    void close() {
        {
            std::unique_lock<std::mutex> lk(m_);
            closed_ = true;
        }
        cv_.notify_all();          // wake ALL consumers so they can notice the closure
    }

    std::size_t size() const {
        std::unique_lock<std::mutex> lk(m_);
        return q_.size();
    }

private:
    mutable std::mutex m_;
    std::condition_variable cv_;
    std::queue<T> q_;
    bool closed_ = false;
};
