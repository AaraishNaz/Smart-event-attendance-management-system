// AttendanceEngine.h - the check-in business logic (Modules 5 and 7)
#pragma once
#include "Database.h"
#include <string>

enum class CheckInResult { SUCCESS = 0, ALREADY_CHECKED_IN, UNKNOWN_ATTENDEE, UNKNOWN_SESSION, SESSION_FULL, DATABASE_ERROR };

inline const char* toString(CheckInResult r) {
    switch (r) {
        case CheckInResult::SUCCESS:          return "SUCCESS";
        case CheckInResult::ALREADY_CHECKED_IN:        return "DUPLICATE";
        case CheckInResult::UNKNOWN_ATTENDEE: return "UNKNOWN_ATTENDEE";
        case CheckInResult::UNKNOWN_SESSION:  return "UNKNOWN_SESSION";
        case CheckInResult::SESSION_FULL:     return "SESSION_FULL";
        default:                              return "DATABASE_ERROR";
    }
}

struct ScanRequest {
    std::string code;       // QR payload (from a USB scanner "keyboard") OR manually typed attendee ID
    int sessionId = 0;      // the session of the kiosk that produced the scan
    std::string kioskId;
};

struct ScanOutcome {
    CheckInResult result = CheckInResult::DATABASE_ERROR;
    std::string message;
    std::string attendeeName;
    long long attendeeId = 0;
};

class AttendanceEngine {
public:
    // Processes ONE scan on the caller's own connection. Never throws for expected failures.
    // Check, capacity test and insert happen inside a single BEGIN IMMEDIATE transaction -> atomic.
    static ScanOutcome checkIn(Database& db, const ScanRequest& req);
};
