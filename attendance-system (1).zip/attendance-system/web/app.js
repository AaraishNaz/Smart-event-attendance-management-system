/* Smart Event Attendance - frontend. Plain JavaScript, no frameworks.
   Every number shown comes from the C++ REST API (/api/...), which reads the SQLite database. */
"use strict";
const $ = (s) => document.querySelector(s);
const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const css = (n) => getComputedStyle(document.documentElement).getPropertyValue(n).trim();

async function api(path, method = "GET", body) {
  const opt = { method, headers: {} };
  if (body !== undefined) { opt.headers["Content-Type"] = "application/json"; opt.body = JSON.stringify(body); }
  try {
    const r = await fetch(path, opt);
    let data = null; try { data = await r.json(); } catch (e) { /* not json */ }
    return { status: r.status, ok: r.ok, data };
  } catch (e) { return { status: 0, ok: false, data: { error: "Cannot reach the server" } }; }
}
function toast(msg) { const t = $("#toast"); t.textContent = msg; t.classList.add("show"); setTimeout(() => t.classList.remove("show"), 2200); }
const pretty = (k) => k.replace(/_/g, " ");
const pctClass = (p) => (p >= 100 ? "full" : p >= 80 ? "mid" : "");
const bar = (p) => `<div class="bar ${pctClass(p)}"><i style="width:${Math.min(100, p || 0)}%"></i></div>`;

function renderTable(el, rows, opts = {}) {
  if (!rows || !rows.length) { el.innerHTML = `<tr><td class="muted">No data</td></tr>`; return; }
  const keys = Object.keys(rows[0]);
  el.innerHTML = `<thead><tr>${keys.map((k) => `<th>${esc(pretty(k))}</th>`).join("")}</tr></thead><tbody>` +
    rows.map((r) => `<tr>${keys.map((k) => `<td>${k.endsWith("_pct") ? esc(r[k]) + " %" : esc(r[k])}</td>`).join("")}</tr>`).join("") + "</tbody>";
}

/* ------------------------------------------------------------ navigation */
let timer = null;
function show(page) {
  document.querySelectorAll(".page").forEach((p) => p.classList.toggle("active", p.id === "page-" + page));
  document.querySelectorAll("nav a").forEach((a) => a.classList.toggle("active", a.dataset.page === page));
  $("#nav").classList.remove("open");
  clearInterval(timer);
  const loaders = { dashboard: loadDashboard, events: loadEvents, sessions: loadSessions, attendees: loadAttendees, kiosk: loadKiosk, reports: loadReport };
  if (loaders[page]) loaders[page]();
  if (page === "dashboard") timer = setInterval(loadDashboard, 5000);   // periodic refresh
}
window.addEventListener("hashchange", () => show(location.hash.slice(1) || "dashboard"));
$("#menuBtn").onclick = () => $("#nav").classList.toggle("open");

/* ------------------------------------------------------------ modal form helper */
function openForm(title, fields, values, submit) {
  $("#dlgTitle").textContent = title; $("#dlgError").textContent = "";
  $("#dlgFields").innerHTML = fields.map((f) => {
    const v = values?.[f.k] ?? f.def ?? "";
    let input;
    if (f.type === "select") input = `<select name="${f.k}">${f.options.map((o) => `<option value="${esc(o.v)}" ${String(o.v) === String(v) ? "selected" : ""}>${esc(o.l)}</option>`).join("")}</select>`;
    else input = `<input name="${f.k}" type="${f.type || "text"}" value="${esc(v)}" ${f.req ? "required" : ""} ${f.min ? `min="${f.min}"` : ""}>`;
    return `<label>${esc(f.label)}</label>${input}`;
  }).join("");
  const dlg = $("#dlg");
  $("#dlgCancel").onclick = () => dlg.close();
  $("#dlgForm").onsubmit = async (e) => {
    e.preventDefault();
    const o = {}; new FormData($("#dlgForm")).forEach((val, k) => (o[k] = val));
    const r = await submit(o);
    if (r.ok) { dlg.close(); toast("Saved"); } else $("#dlgError").textContent = r.data?.error || "Request failed";
  };
  dlg.showModal();
}
async function confirmDelete(url, what, reload) {
  if (!confirm(`Delete this ${what}?`)) return;
  const r = await api(url, "DELETE");
  if (r.ok) { toast("Deleted"); reload(); } else alert(r.data?.error || "Delete failed");
}

/* ------------------------------------------------------------ charts (canvas) */
function prepCanvas(c, h) {
  const dpr = window.devicePixelRatio || 1, w = c.clientWidth || 400;
  c.width = w * dpr; c.height = h * dpr;
  const g = c.getContext("2d"); g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, w, h);
  g.font = "13px system-ui, sans-serif"; g.textBaseline = "middle";
  return { g, w };
}
function drawSessionChart(sessions) {
  const c = $("#chartSessions"), h = Math.max(200, sessions.length * 36 + 20), { g, w } = prepCanvas(c, h);
  const left = Math.min(170, w * 0.4), right = 70;
  sessions.forEach((s, i) => {
    const y = 12 + i * 36, bw = w - left - right, p = s.utilization_pct;
    g.fillStyle = css("--text"); g.textAlign = "left";
    g.fillText(s.title.length > 24 ? s.title.slice(0, 23) + "…" : s.title, 0, y + 11);
    g.fillStyle = css("--line"); g.fillRect(left, y, bw, 22);
    g.fillStyle = p >= 100 ? css("--bad") : p >= 80 ? css("--warn") : css("--brand");
    g.fillRect(left, y, bw * Math.min(1, s.checked_in / s.capacity), 22);
    g.fillStyle = css("--text"); g.fillText(`${s.checked_in}/${s.capacity}`, left + bw + 8, y + 11);
  });
}
const RESULT_COLORS = { SUCCESS: "#2f9e44", DUPLICATE: "#f08c00", SESSION_FULL: "#e03131", UNKNOWN_ATTENDEE: "#862e9c", UNKNOWN_SESSION: "#be4bdb", DATABASE_ERROR: "#343a40" };
function drawResultChart(rows) {
  const c = $("#chartResults"), { g, w } = prepCanvas(c, 260), total = rows.reduce((a, r) => a + r.count, 0);
  $("#legend").innerHTML = rows.map((r) => `<span><i style="background:${RESULT_COLORS[r.result] || "#888"}"></i>${esc(r.result)} (${r.count})</span>`).join("");
  if (!total) { g.fillStyle = css("--muted"); g.textAlign = "center"; g.fillText("No scans yet", w / 2, 130); return; }
  const cx = w / 2, cy = 130, R = 100; let a = -Math.PI / 2;
  rows.forEach((r) => {
    const da = (r.count / total) * Math.PI * 2;
    g.beginPath(); g.moveTo(cx, cy); g.arc(cx, cy, R, a, a + da); g.closePath();
    g.fillStyle = RESULT_COLORS[r.result] || "#888"; g.fill(); a += da;
  });
  g.beginPath(); g.arc(cx, cy, 58, 0, Math.PI * 2); g.fillStyle = css("--panel"); g.fill();
  g.fillStyle = css("--text"); g.textAlign = "center"; g.font = "bold 22px system-ui"; g.fillText(total, cx, cy - 6);
  g.font = "12px system-ui"; g.fillStyle = css("--muted"); g.fillText("scans", cx, cy + 14);
}

/* ------------------------------------------------------------ dashboard */
let dash = null;
async function loadDashboard() {
  const r = await api("/api/dashboard");
  if (!r.ok) { $("#updated").textContent = "server not reachable"; return; }
  dash = r.data; const t = dash.totals;
  $("#cards").innerHTML = [
    ["Events", t.events, ""], ["Registered attendees", t.attendees, ""], ["Sessions", t.sessions, ""],
    ["Successful check-ins", t.checkins, "ok"], ["Duplicate scans", t.duplicates, "warn"],
    ["Remaining capacity", t.remaining_capacity, "info"], ["Overall attendance", t.attendance_pct.toFixed(1) + " %", "ok"]]
    .map(([l, v, c]) => `<div class="card ${c}"><div class="v">${esc(v)}</div><div class="l">${l}</div></div>`).join("");
  const rooms = [...new Set(dash.sessions.map((s) => s.room))], sel = $("#dashRoom"), cur = sel.value;
  sel.innerHTML = `<option value="">All rooms</option>` + rooms.map((x) => `<option ${x === cur ? "selected" : ""}>${esc(x)}</option>`).join("");
  drawSessionChart(dash.sessions); drawResultChart(dash.scan_results);
  const groupBars = (rows, key) => rows.map((x) => `<div class="barrow"><span>${esc(x[key])}</span>${bar(x.attendance_pct)}<span>${x.checkins}/${x.capacity} (${x.attendance_pct}%)</span></div>`).join("");
  $("#topicBars").innerHTML = groupBars(dash.topics, "topic_name"); $("#roomBars").innerHTML = groupBars(dash.rooms, "room");
  renderTable($("#recentTable"), dash.recent);
  renderDashTable();
  $("#updated").textContent = "updated " + new Date().toLocaleTimeString();
}
function renderDashTable() {
  if (!dash) return;
  const q = $("#dashSearch").value.toLowerCase(), room = $("#dashRoom").value;
  const rows = dash.sessions.filter((s) => (!room || s.room === room) && (!q || [s.title, s.topic_name, s.room, s.event_name].join(" ").toLowerCase().includes(q)));
  $("#dashTable").innerHTML = `<thead><tr><th>Session</th><th>Topic</th><th>Room</th><th>Time</th><th>Checked in</th><th>Capacity</th><th>Remaining</th><th>Attendance</th><th>Duplicates</th></tr></thead><tbody>` +
    rows.map((s) => `<tr><td>${esc(s.title)}</td><td>${esc(s.topic_name)}</td><td>${esc(s.room)}</td><td>${esc(s.start_time.slice(5))}</td><td>${s.checked_in}</td><td>${s.capacity}</td><td>${s.remaining}</td><td>${bar(s.utilization_pct)} ${s.utilization_pct}%</td><td>${s.duplicate_scans}</td></tr>`).join("") + "</tbody>";
}
$("#dashSearch").oninput = renderDashTable; $("#dashRoom").onchange = renderDashTable;
window.addEventListener("resize", () => { if (dash && $("#page-dashboard").classList.contains("active")) { drawSessionChart(dash.sessions); drawResultChart(dash.scan_results); } });

/* ------------------------------------------------------------ events */
async function loadEvents() {
  const r = await api("/api/events"); const rows = r.data || [];
  $("#eventsTable").innerHTML = `<thead><tr><th>ID</th><th>Name</th><th>Location</th><th>Dates</th><th>Topics</th><th>Sessions</th><th></th></tr></thead><tbody>` +
    rows.map((e) => `<tr><td>${e.event_id}</td><td>${esc(e.name)}</td><td>${esc(e.location)}</td><td>${esc(e.start_date)} → ${esc(e.end_date)}</td><td>${esc(e.topics)}</td><td>${e.session_count}</td>
    <td>${authUser && ['admin','organizer'].includes(authUser.role) ? `<button class="btn small" data-edit="${e.event_id}">Edit</button> <button class="btn small ghost" data-topic="${e.event_id}">+ Topic</button> <button class="btn small danger" data-del="${e.event_id}">Delete</button>` : ''}</td></tr>`).join("") + "</tbody>";
  $("#eventsTable").onclick = async (ev) => {
    const b = ev.target.closest("button"); if (!b) return;
    if (b.dataset.del) confirmDelete(`/api/events/${b.dataset.del}`, "event", loadEvents);
    if (b.dataset.topic) openForm("Add topic", [{ k: "name", label: "Topic name", req: true }], {}, async (o) => { const x = await api(`/api/events/${b.dataset.topic}/topics`, "POST", o); loadEvents(); return x; });
    if (b.dataset.edit) { const cur = rows.find((x) => x.event_id == b.dataset.edit); openForm("Edit event", eventFields(false), cur, async (o) => { const x = await api(`/api/events/${cur.event_id}`, "PUT", o); loadEvents(); return x; }); }
  };
}
const eventFields = (isNew) => [{ k: "name", label: "Event name", req: true }, { k: "location", label: "Location", req: true },
  { k: "start_date", label: "Start date", type: "date", req: true }, { k: "end_date", label: "End date", type: "date", req: true },
  { k: "description", label: "Description" }, ...(isNew ? [{ k: "topics", label: "Topics (comma separated)" }] : [])];
$("#addEvent").onclick = () => openForm("New event", eventFields(true), {}, async (o) => {
  o.topics = (o.topics || "").split(",").map((s) => s.trim()).filter(Boolean);
  const x = await api("/api/events", "POST", o); loadEvents(); return x; });

/* ------------------------------------------------------------ sessions */
async function loadSessions() {
  const r = await api("/api/sessions"); const rows = r.data || [];
  $("#sessionsTable").innerHTML = `<thead><tr><th>ID</th><th>Title</th><th>Event</th><th>Topic</th><th>Room</th><th>Start</th><th>End</th><th>Occupancy</th><th></th></tr></thead><tbody>` +
    rows.map((s) => `<tr><td>${s.session_id}</td><td>${esc(s.title)}</td><td>${esc(s.event_name)}</td><td>${esc(s.topic_name)}</td><td>${esc(s.room)}</td><td>${esc(s.start_time)}</td><td>${esc(s.end_time.slice(11))}</td>
    <td>${bar(s.utilization_pct)} ${s.checked_in}/${s.capacity}</td><td>${authUser && ['admin','organizer'].includes(authUser.role) ? `<button class="btn small" data-edit="${s.session_id}">Edit</button> <button class="btn small danger" data-del="${s.session_id}">Delete</button>` : ''}</td></tr>`).join("") + "</tbody>";
  $("#sessionsTable").onclick = (ev) => {
    const b = ev.target.closest("button"); if (!b) return;
    if (b.dataset.del) confirmDelete(`/api/sessions/${b.dataset.del}`, "session", loadSessions);
    if (b.dataset.edit) { const cur = rows.find((x) => x.session_id == b.dataset.edit); sessionForm("Edit session", { ...cur, start_time: cur.start_time.replace(" ", "T"), end_time: cur.end_time.replace(" ", "T") }, cur.session_id); }
  };
}
async function sessionForm(title, values, id) {
  const [ev, tp] = await Promise.all([api("/api/events"), api("/api/topics")]);
  const fields = [
    { k: "event_id", label: "Event", type: "select", options: (ev.data || []).map((e) => ({ v: e.event_id, l: e.name })) },
    { k: "topic_id", label: "Topic", type: "select", options: [{ v: "", l: "(none)" }, ...(tp.data || []).map((t) => ({ v: t.topic_id, l: `${t.event_name}: ${t.name}` }))] },
    { k: "title", label: "Session title", req: true }, { k: "room", label: "Room", req: true },
    { k: "start_time", label: "Start", type: "datetime-local", req: true }, { k: "end_time", label: "End", type: "datetime-local", req: true },
    { k: "capacity", label: "Maximum capacity", type: "number", min: 1, req: true }];
  openForm(title, fields, values, async (o) => {
    const x = id ? await api(`/api/sessions/${id}`, "PUT", o) : await api("/api/sessions", "POST", o); loadSessions(); return x; });
}
$("#addSession").onclick = () => sessionForm("New session", { capacity: 30 });

/* ------------------------------------------------------------ attendees */
let attTimer = null;
async function loadAttendees() {
  const r = await api("/api/attendees?q=" + encodeURIComponent($("#attSearch").value)); const rows = r.data || [];
  $("#attCount").textContent = rows.length + " attendees";
  $("#attTable").innerHTML = `<thead><tr><th>ID</th><th>Name</th><th>E-mail</th><th>Phone</th><th>Organization</th><th>QR identifier</th><th>Sessions</th><th></th></tr></thead><tbody>` +
    rows.map((a) => `<tr><td><b>${esc(a.attendee_code)}</b></td><td>${esc(a.name)}</td><td>${esc(a.email)}</td><td>${esc(a.phone)}</td><td>${esc(a.organization)}</td><td><code>${esc(a.qr_code)}</code></td><td>${a.sessions_attended}</td>
    <td><button class="btn small" data-edit="${a.attendee_id}">Edit</button> <button class="btn small danger" data-del="${a.attendee_id}">Delete</button></td></tr>`).join("") + "</tbody>";
  $("#attTable").onclick = (ev) => {
    const b = ev.target.closest("button"); if (!b) return;
    if (b.dataset.del) confirmDelete(`/api/attendees/${b.dataset.del}`, "attendee", loadAttendees);
    if (b.dataset.edit) { const cur = rows.find((x) => x.attendee_id == b.dataset.edit); openForm("Edit attendee", attFields, cur, async (o) => { const x = await api(`/api/attendees/${cur.attendee_id}`, "PUT", o); loadAttendees(); return x; }); }
  };
}
const attFields = [{ k: "name", label: "Full name", req: true }, { k: "email", label: "E-mail", type: "email", req: true }, { k: "phone", label: "Phone" }, { k: "organization", label: "Organization / branch" }];
$("#addAttendee").onclick = () => openForm("Register attendee", attFields, {}, async (o) => { const x = await api("/api/attendees", "POST", o); loadAttendees(); return x; });
$("#attSearch").oninput = () => { clearTimeout(attTimer); attTimer = setTimeout(loadAttendees, 250); };

/* ------------------------------------------------------------ kiosk */
let kioskSessions = [], allAttendees = null;
async function loadKiosk() {
  const r = await api("/api/sessions"); kioskSessions = r.data || [];
  const sel = $("#kioskSession"), cur = sel.value;
  sel.innerHTML = kioskSessions.map((s) => `<option value="${s.session_id}" ${String(s.session_id) === cur ? "selected" : ""}>${esc(s.room)} — ${esc(s.title)} (${s.checked_in}/${s.capacity})</option>`).join("");
  $("#kioskInput").focus();
}
async function doScan(code) {
  code = code.trim(); if (!code) return;
  const sid = Number($("#kioskSession").value), s = kioskSessions.find((x) => x.session_id === sid);
  const r = await api("/api/checkin", "POST", { code, session_id: sid, kiosk_id: "WEB-" + (s ? s.room : sid) });
  const d = r.data || { result: "DATABASE_ERROR", message: "No answer from server" };
  $("#kioskResult").className = "result " + d.result;
  $("#kioskResult").innerHTML = `${esc(d.result)}<small>${esc(d.message || d.error)}</small>`;
  const row = document.createElement("div");
  row.innerHTML = `<span class="badge ${esc(d.result)}">${esc(d.result)}</span><span>${esc(d.attendee_name || code)}</span><span class="muted small">${new Date().toLocaleTimeString()}</span>`;
  $("#kioskLog").prepend(row);
  $("#kioskInput").value = ""; $("#kioskInput").focus();
  loadKiosk();
}
$("#kioskInput").onkeydown = (e) => { if (e.key === "Enter") doScan(e.target.value); };
$("#kioskGo").onclick = () => doScan($("#kioskInput").value);
$("#kioskRandom").onclick = async () => {
  if (!allAttendees) allAttendees = (await api("/api/attendees")).data || [];
  if (allAttendees.length) doScan(allAttendees[Math.floor(Math.random() * allAttendees.length)].attendee_code);
};

/* ------------------------------------------------------------ reports */
async function loadReport() {
  const audit = await api('/api/class-attendance'); if(audit.ok) renderTable($('#classAuditTable'),audit.data);
  const type = $("#reportType").value;
  $("#csvLink").href = `/api/reports/${type}?format=csv`;
  const r = await api(`/api/reports/${type}`); renderTable($("#reportTable"), r.data);
}
$("#reportType").onchange = loadReport;
$("#integrityBtn").onclick = async () => {
  const r = await api("/api/integrity"); const o = $("#integrityOut");
  o.classList.remove("hidden"); o.textContent = JSON.stringify(r.data, null, 2);
};
$("#histGo").onclick = async () => {
  const q = $("#histSearch").value.trim(); if (!q) return;
  const found = (await api("/api/attendees?q=" + encodeURIComponent(q))).data || [];
  if (!found.length) { $("#histOut").innerHTML = `<p class="muted">No attendee found</p>`; return; }
  const h = (await api(`/api/attendees/${found[0].attendee_id}/history`)).data;
  $("#histOut").innerHTML = `<p><b>${esc(h.attendee.name)}</b> (${esc(h.attendee.attendee_code)}) attended ${h.history.length} session(s)</p><div class="table-wrap"><table id="histTable"></table></div>`;
  renderTable($("#histTable"), h.history);
};

/* ------------------------------------------------------------ concurrency lab */
$("#labRun").onclick = async () => {
  $("#labStatus").textContent = "running..."; $("#labOut").innerHTML = "";
  const r = await api("/api/demo/concurrency", "POST", {});
  $("#labStatus").textContent = ""; if (!r.ok) { $("#labOut").textContent = r.data?.error || "failed"; return; }
  const d = r.data, s = d.safe, u = d.unsafe;
  const box = (cls, title, x, extra) => `<div class="box ${cls}"><h2>${title}</h2><b class="big">${x.attendance_rows} / ${d.capacity}</b>seats taken (capacity ${d.capacity})
    <p>Overbooked by: <b>${x.overbooked_by}</b><br>Duplicate rows: <b>${x.duplicate_rows}</b><br>Integrity: <b>${x.integrity_ok ? "OK" : "BROKEN"}</b>${extra || ""}</p></div>`;
  $("#labOut").innerHTML = `<div class="cmp">${box("good", "SAFE (queue + transactions + UNIQUE)", s, `<br>Lost scans: <b>${s.lost_scans}</b>`)}${box(u.integrity_ok ? "good" : "bad", "UNSAFE (no synchronization)", u)}</div>
    <p class="muted small">Race conditions are timing dependent: run the unsafe version a few times to see different numbers.</p>`;
};
$("#stressRun").onclick = async () => {
  $("#stressStatus").textContent = "running..."; $("#stressTable").innerHTML = "";
  const r = await api("/api/demo/stress", "POST", { config: Number($("#stressCfg").value) });
  $("#stressStatus").textContent = ""; if (!r.ok) { $("#stressTable").innerHTML = `<tr><td>${esc(r.data?.error)}</td></tr>`; return; }
  renderTable($("#stressTable"), r.data.map((x) => ({ workload: x.name, total_scans: x.total_scans, successful: x.successful, duplicates: x.duplicates, rejected: x.rejected,
    database_errors: x.database_errors, lost_scans: x.lost_scans, seconds: x.seconds.toFixed(3), scans_per_sec: Math.round(x.throughput_per_sec), integrity: x.integrity_ok ? "OK" : "BROKEN" })));
};

show(location.hash.slice(1) || "dashboard");


/* ------------------------------------------------------------ GEHU authentication + role dashboards */
let authUser = null, qrTimer = null, qrLoop = null;
async function refreshAuth() {
  const r = await api('/api/auth/me');
  if (!r.ok) { authUser=null; $('#loginScreen').hidden=false; $('#topbar').hidden=true; $('#appMain').hidden=true; return; }
  authUser=r.data; $('#loginScreen').hidden=true; $('#topbar').hidden=false; $('#appMain').hidden=false;
  $('#userLabel').textContent = `${authUser.display_name} · ${authUser.role}`;
  ['addEvent','addSession','addAttendee'].forEach(id=>{const el=$('#'+id);if(el)el.hidden=!['admin','organizer'].includes(authUser.role);});
  document.querySelectorAll('nav a[data-roles]').forEach(a=>{a.hidden=!a.dataset.roles.split(',').includes(authUser.role)});
  document.querySelectorAll('nav a[data-page]').forEach(a=>{
    const p=a.dataset.page;
    if(authUser.role==='student' && !['events','sessions','my'].includes(p)) a.hidden=true;
    if(authUser.role==='teacher' && ['kiosk','attendees','lab','qr','my','approvals'].includes(p)) a.hidden=true;
    if(authUser.role==='organizer' && ['attendees','lab','my','approvals'].includes(p)) a.hidden=true;
  });
  if(authUser.role==='student'){location.hash='#my';show('my');}
  else if(authUser.role==='organizer'){location.hash='#qr';show('qr');}
  else if(authUser.role==='admin'){location.hash='#dashboard';show('dashboard');}
  else if(authUser.role==='teacher'){location.hash='#classes';show('classes');}
  else {location.hash='#dashboard';show('dashboard');}
}
const roleLabels={student:'Student',teacher:'Teacher',organizer:'Organizer',admin:'Admin'};
document.querySelectorAll('.role-card').forEach(card=>card.addEventListener('click',()=>{
  document.querySelectorAll('.role-card').forEach(x=>x.classList.toggle('selected',x===card));
  $('#selectedRole').value=card.dataset.role;
  $('#loginForm .login-submit').textContent=`Continue as ${roleLabels[card.dataset.role]}`;
  $('#loginError').textContent='';
}));
$('#loginForm').addEventListener('submit',async e=>{
  e.preventDefault(); $('#loginError').textContent='';
  const r=await api('/api/auth/login','POST',{username:$('#loginUsername').value.trim(),password:$('#loginPassword').value});
  if(!r.ok){$('#loginError').textContent=r.data?.error||'Login failed';return;}
  if(r.data?.role && r.data.role!==$('#selectedRole').value){
    await api('/api/auth/logout','POST',{});
    $('#loginError').textContent=`This account is registered as ${roleLabels[r.data.role]||r.data.role}. Please select the matching role.`;return;
  }
  $('#loginPassword').value=''; await refreshAuth(); toast('Welcome to GEHU Smart Attendance');
});
$('#logoutBtn').addEventListener('click',async()=>{await api('/api/auth/logout','POST',{});clearInterval(qrLoop);clearInterval(qrTimer);clearInterval(qrScanLoop);if(qrStream)qrStream.getTracks().forEach(t=>t.stop());qrStream=null;authUser=null;$('#loginScreen').hidden=false;$('#topbar').hidden=true;$('#appMain').hidden=true;location.hash='';});
async function loadMyAttendance(){
  const r=await api('/api/my/attendance'); if(!r.ok){toast(r.data?.error||'Could not load attendance');return;}
  renderTable($('#myEvents'),r.data.events); renderTable($('#myClasses'),r.data.classes);
  const subj=r.data.subjects||[];
  $('#mySubjects').innerHTML=subj.length?subj.map(s=>{const low=s.percentage<75;return `<div class="card ${low?'low':'ok'}"><div class="l">${esc(s.subject)}</div><div class="v">${s.percentage}%</div><div class="sub">${s.present} present / ${s.total_classes} classes</div><div class="bar ${low?'low':''}"><i style="width:${Math.min(100,s.percentage)}%"></i></div>${low?'<div class="small" style="color:var(--bad);margin-top:6px">Below 75%</div>':''}</div>`;}).join(''):'<p class="muted">No classes yet.</p>';
}
$('#refreshMy').onclick=loadMyAttendance;
let qrStream=null, qrScanLoop=null;
$('#cameraStart').onclick=async()=>{
  const video=$('#qrVideo'),out=$('#classCheckinResult');
  if(!navigator.mediaDevices?.getUserMedia){out.className='result error';out.textContent='Camera access is unavailable. Open this app in Chrome on localhost and allow camera permission.';return;}
  if(typeof jsQR!=='function'){out.className='result error';out.textContent='QR scanner library did not load. Check your internet connection and reload the page.';return;}
  try{
    qrStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'}},audio:false});
    video.srcObject=qrStream;video.hidden=false;await video.play();
    const canvas=document.createElement('canvas'),ctx=canvas.getContext('2d',{willReadFrequently:true});
    clearInterval(qrScanLoop);qrScanLoop=setInterval(()=>{
      if(video.readyState<2||!video.videoWidth)return;
      canvas.width=video.videoWidth;canvas.height=video.videoHeight;
      ctx.drawImage(video,0,0,canvas.width,canvas.height);
      const frame=ctx.getImageData(0,0,canvas.width,canvas.height);
      const code=jsQR(frame.data,frame.width,frame.height,{inversionAttempts:'attemptBoth'});
      if(!code)return;
      try{
        const parsed=JSON.parse(code.data);
        if(parsed.class_id&&parsed.token){
          clearInterval(qrScanLoop);if(qrStream)qrStream.getTracks().forEach(t=>t.stop());qrStream=null;video.hidden=true;
          $('#classCodeInput').value=parsed.token;$('#classCheckin').click();return;
        }
        if(!parsed.session_id||!parsed.token)return;
        $('#studentQrToken').value=parsed.token;
        clearInterval(qrScanLoop);
        if(qrStream)qrStream.getTracks().forEach(t=>t.stop());
        qrStream=null;video.hidden=true;
        $('#studentCheckin').click();   // event QR scanned -> mark immediately
      }catch(e){out.className='result error';out.textContent='QR detected, but its contents were not a valid attendance token.';}
    },150);
  }catch(e){out.className='result error';out.textContent='Could not access camera. Allow camera permission in Chrome site settings and try again.';}
};
$('#cameraStop').onclick=()=>{clearInterval(qrScanLoop);if(qrStream)qrStream.getTracks().forEach(t=>t.stop());qrStream=null;$('#qrVideo').hidden=true;};
$('#studentCheckin').onclick=async()=>{
  const token=$('#studentQrToken').value.trim();
  const out=$('#studentCheckinResult'); if(!/^\d{3}$/.test(token)){out.className='result error';out.textContent='Enter the 3-digit code';return;}
  const r=await api('/api/event-checkin','POST',{qr_token:token});
  out.className='result '+(r.ok?'success':'error');out.textContent=r.data?.message||r.data?.error||'Request failed';
  if(r.ok)loadMyAttendance();
};
async function loadQrSessions(){
  const r=await api('/api/sessions');const sessions=r.data||[];const sel=$('#qrSession');
  sel.innerHTML=sessions.map(s=>`<option value="${s.session_id}">${esc(s.title)} · ${esc(s.room)} · ${esc(s.start_time)}</option>`).join('');
  if(sessions.length)startQrRotation();
}
async function startQrRotation(){
  clearInterval(qrLoop); const sid=$('#qrSession').value; if(!sid)return;
  const refresh=async()=>{
    const r=await api(`/api/sessions/${sid}/qr-token`);
    const box=$('#qrCanvas');box.innerHTML='';
    if(!r.ok){$('#qrCountdown').textContent=r.data?.error||'QR unavailable';return;}
    const payload=JSON.stringify({session_id:Number(sid),token:r.data.token});
    if(window.QRCode) new QRCode(box,{text:payload,width:220,height:220}); else box.textContent=payload;
    $('#qrBig').textContent=r.data.token;$('#qrMeta').textContent=`${r.data.event} · ${r.data.session}`;
    let left=10;$('#qrCountdown').textContent=`Refreshes in ${left}s`;
    clearInterval(qrTimer);qrTimer=setInterval(()=>{left--;if(left<=0){clearInterval(qrTimer);$('#qrCountdown').textContent='Refreshing…';refresh();return;}$('#qrCountdown').textContent=`Refreshes in ${left}s`;},1000);
  };
  await refresh();
}
$('#qrSession').addEventListener('change',startQrRotation);
/* ---------- class attendance: student side ---------- */
$('#classCheckin').onclick=async()=>{
  const out=$('#classCheckinResult'),code=$('#classCodeInput').value.trim();
  if(!/^\d{3}$/.test(code)){out.className='result error';out.textContent='Enter the 3-digit code';return;}
  const r=await api('/api/class-checkin','POST',{qr_token:code});
  out.className='result '+(r.ok?'success':'error');out.textContent=r.data?.message||r.data?.error||'Request failed';
  if(r.ok){$('#classCodeInput').value='';loadMyAttendance();}
};
$('#classCodeInput').addEventListener('keydown',e=>{if(e.key==='Enter')$('#classCheckin').click();});

/* ---------- class attendance: teacher side ---------- */
let classId=null,classQrLoop=null,classCdTimer=null,rosterLoop=null;
function stopClassLive(){clearInterval(classQrLoop);clearInterval(classCdTimer);clearInterval(rosterLoop);}
async function loadClasses(){
  const r=await api('/api/teacher/classes');const rows=r.data||[];
  $('#classList').innerHTML=`<thead><tr><th>Subject</th><th>Date</th><th>Start</th><th>Present</th><th></th></tr></thead><tbody>`+
    rows.map(c=>`<tr><td>${esc(c.subject)}</td><td>${esc(c.class_date)}</td><td>${esc(c.start_time)}</td><td>${c.present} / ${c.total_students}</td><td><button class="btn small" data-open="${c.class_session_id}" data-name="${esc(c.subject)}">Open QR &amp; attendance</button></td></tr>`).join('')+'</tbody>';
}
$('#classList').onclick=e=>{const b=e.target.closest('button');if(b&&b.dataset.open)openClass(Number(b.dataset.open),b.dataset.name);};
$('#startClass').onclick=async()=>{
  const name=$('#classSubject').value.trim();if(!name){toast('Enter the subject');return;}
  const r=await api('/api/teacher/classes','POST',{class_name:name,room:$('#classRoom').value.trim()});
  if(!r.ok){toast(r.data?.error||'Could not start class');return;}
  await loadClasses();openClass(r.data.class_session_id,name);
};
async function openClass(id,name){
  stopClassLive();classId=id;$('#classLive').hidden=false;$('#liveTitle').textContent=name+' — show this QR to students';
  const refreshQr=async()=>{
    const r=await api(`/api/teacher/classes/${id}/qr-token`);const box=$('#classQr');box.innerHTML='';
    if(!r.ok){$('#classCountdown').textContent=r.data?.error||'QR unavailable';return;}
    const payload=JSON.stringify({class_id:id,token:r.data.token});
    if(window.QRCode) new QRCode(box,{text:payload,width:220,height:220}); else box.textContent='(QR library not loaded - use the code)';
    $('#classCode').textContent=r.data.token;
    let left=10;$('#classCountdown').textContent=`Changes in ${left}s`;
    clearInterval(classCdTimer);classCdTimer=setInterval(()=>{left--;if(left<=0){clearInterval(classCdTimer);$('#classCountdown').textContent='Changing...';refreshQr();return;}$('#classCountdown').textContent=`Changes in ${left}s`;},1000);
  };
  const refreshRoster=async()=>{
    const r=await api(`/api/teacher/classes/${id}/attendance`);const rows=r.data||[];
    const present=rows.filter(x=>x.status!=='ABSENT').length;$('#liveCount').textContent=`(${present} / ${rows.length} present)`;
    $('#classRoster').innerHTML=`<thead><tr><th>Student</th><th>ID</th><th>Status</th><th>Time</th><th></th></tr></thead><tbody>`+
      rows.map(x=>`<tr><td>${esc(x.student)}</td><td>${esc(x.attendee_code)}</td><td class="st-${esc(x.status)}">${esc(x.status==='PRESENT_VIA_APPROVED_EVENT'?'PRESENT (via event)':x.status)}</td><td>${esc(x.marked_at||'')}</td>
      <td><button class="btn small ${x.status==='ABSENT'?'':'ghost'}" data-mark="${x.attendee_id}" data-to="${x.status==='ABSENT'?'PRESENT':'ABSENT'}">${x.status==='ABSENT'?'Mark present':'Mark absent'}</button></td></tr>`).join('')+'</tbody>';
  };
  $('#classRoster').onclick=async e=>{const b=e.target.closest('button');if(!b||!b.dataset.mark)return;
    await api(`/api/teacher/classes/${id}/mark`,'POST',{attendee_id:Number(b.dataset.mark),status:b.dataset.to});refreshRoster();loadClasses();};
  await refreshQr();await refreshRoster();
  rosterLoop=setInterval(()=>{refreshRoster();loadClasses();},3000);
}
const oldShow=show;
show=function(page){if(page!=='qr'){clearInterval(qrLoop);clearInterval(qrTimer);}if(page!=='classes')stopClassLive();if(page==='classes'&&authUser&&['teacher','admin'].includes(authUser.role))loadClasses();oldShow(page);if(page==='qr'&&authUser&&['admin','organizer'].includes(authUser.role))loadQrSessions();if(page==='my'&&authUser?.role==='student')loadMyAttendance();if(page==='approvals'&&authUser?.role==='admin')loadApprovals();};
window.addEventListener('load',refreshAuth);
