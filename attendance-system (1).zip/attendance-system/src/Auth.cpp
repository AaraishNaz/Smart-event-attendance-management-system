#include "Auth.h"
#include <array>
#include <vector>
#include <stdexcept>
#include <functional>
#include <iomanip>
#include <random>
#include <sstream>
#ifdef _WIN32
#include <windows.h>
#include <bcrypt.h>
#endif

static std::string hex(const unsigned char* p, std::size_t n) {
    std::ostringstream o; o << std::hex << std::setfill('0');
    for (std::size_t i=0;i<n;++i) o << std::setw(2) << static_cast<unsigned>(p[i]);
    return o.str();
}
static std::vector<unsigned char> unhex(const std::string& s) {
    std::vector<unsigned char> v;
    for (std::size_t i=0;i+1<s.size();i+=2) v.push_back(static_cast<unsigned char>(std::stoul(s.substr(i,2),nullptr,16)));
    return v;
}
std::string randomToken(std::size_t bytes) {
    std::vector<unsigned char> b(bytes);
#ifdef _WIN32
    if (BCryptGenRandom(nullptr, b.data(), static_cast<ULONG>(b.size()), BCRYPT_USE_SYSTEM_PREFERRED_RNG) != 0) throw std::runtime_error("secure random generator failed");
#else
    std::random_device rd; for (auto& x:b) x=static_cast<unsigned char>(rd());
#endif
    return hex(b.data(), b.size());
}
static std::string derive(const std::string& password, const std::vector<unsigned char>& salt) {
    std::array<unsigned char,32> out{};
#ifdef _WIN32
    BCRYPT_ALG_HANDLE alg=nullptr;
    if (BCryptOpenAlgorithmProvider(&alg, BCRYPT_SHA256_ALGORITHM, nullptr, BCRYPT_ALG_HANDLE_HMAC_FLAG) != 0) throw std::runtime_error("SHA-256 provider unavailable");
    NTSTATUS st=BCryptDeriveKeyPBKDF2(alg, reinterpret_cast<PUCHAR>(const_cast<char*>(password.data())), static_cast<ULONG>(password.size()), const_cast<PUCHAR>(salt.data()), static_cast<ULONG>(salt.size()), 120000, out.data(), static_cast<ULONG>(out.size()), 0);
    BCryptCloseAlgorithmProvider(alg,0);
    if (st != 0) throw std::runtime_error("password derivation failed");
#else
    std::hash<std::string> h; std::size_t x=h(password+hex(salt.data(),salt.size()));
    for(int i=0;i<120000;++i) x=h(std::to_string(x)+password);
    for(std::size_t i=0;i<out.size();++i) out[i]=static_cast<unsigned char>((x >> ((i%sizeof(x))*8)) & 255);
#endif
    return hex(out.data(),out.size());
}
std::string makePasswordHash(const std::string& password) { auto salt=unhex(randomToken(16)); return hex(salt.data(),salt.size())+"$"+derive(password,salt); }
bool verifyPassword(const std::string& password,const std::string& stored) {
    auto p=stored.find('$'); if(p==std::string::npos) return false;
    auto salt=unhex(stored.substr(0,p)); return derive(password,salt)==stored.substr(p+1);
}
