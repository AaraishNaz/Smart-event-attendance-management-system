// main.cpp - C++ HTTP server (cpp-httplib) exposing the REST API and serving the web frontend (Modules 8, 9)
//
//   Browser  --HTTP/JSON-->  httplib thread pool  --(reads/CRUD: own SQLite connection per thread)-->  SQLite
//                                   |
//                                   +--POST /api/checkin--> Pipeline (queue + worker threads) --> SQLite
#include <httplib.h>
#include "Database.h"
#include "Auth.h"
#include "Pipeline.h"
#include "Reports.h"
#include "Repository.h"
#include "Schema.h"
#include "Workload.h"
#include <csignal>
#include <filesystem>
#include <iostream>
#include <memory>
#include <mutex>
#include <chrono>
#include <initializer_list>
#include <sstream>
#include <random>

static std::string g_dbPath = "attendance.db";
static httplib::Server* g_server = nullptr;
static std::unique_ptr<Pipeline> g_pipeline;
static std::mutex g_demoMutex;

// One connection per thread: the httplib pool threads live for the whole run, so each opens its connection once.
static Database& conn() {
    thread_local Database db(g_dbPath);
    return db;
}

static void sendJson(httplib::Response& res, int status, const json& body) {
    res.status = status;
    res.set_content(body.dump(), "application/json");
}
static json bodyJson(const httplib::Request& req) { return json::parse(req.body.empty() ? "{}" : req.body); }
static int idOf(const httplib::Request& req) {
    try { return std::stoi(req.matches[1]); } catch (...) { throw ValidationError("invalid id"); }
}
static int intParam(const httplib::Request& req, const char* name, int def = 0) {
    if (!req.has_param(name)) return def;
    try { return std::stoi(req.get_param_value(name)); } catch (...) { throw ValidationError(std::string("invalid ") + name); }
}

// Wraps every handler: converts our exception types into proper HTTP status codes + JSON error bodies.
template <class F>
static httplib::Server::Handler guarded(F fn) {
    return [fn](const httplib::Request& req, httplib::Response& res) {
        try { fn(req, res); }
        catch (const ValidationError& e) { sendJson(res, 400, {{"error", e.what()}}); }
        catch (const NotFound& e)        { sendJson(res, 404, {{"error", e.what()}}); }
        catch (const Forbidden& e)       { sendJson(res, 403, {{"error", e.what()}}); }
        catch (const Conflict& e)        { sendJson(res, 409, {{"error", e.what()}}); }
        catch (const json::exception& e) { sendJson(res, 400, {{"error", std::string("Invalid JSON: ") + e.what()}}); }
        catch (const DbError& e)         { sendJson(res, 500, {{"error", std::string("Database error: ") + e.what()}}); }
        catch (const std::exception& e)  { sendJson(res, 500, {{"error", e.what()}}); }
    };
}


static std::string cookieToken(const httplib::Request& req) {
    std::string c=req.get_header_value("Cookie"), key="gehu_session=";
    auto p=c.find(key); if(p==std::string::npos) return "";
    p+=key.size(); auto e=c.find(';',p); return c.substr(p,e==std::string::npos?std::string::npos:e-p);
}
static json currentUser(const httplib::Request& req) {
    std::string token=cookieToken(req); if(token.empty()) return nullptr;
    auto rows=conn().query("SELECT u.user_id,u.username,u.role,u.display_name,u.attendee_id FROM auth_sessions s JOIN app_users u ON u.user_id=s.user_id WHERE s.token=? AND s.expires_at>datetime('now') AND u.active=1",{token});
    return rows.empty()?json(nullptr):rows[0];
}
static bool hasRole(const httplib::Request& req, std::initializer_list<const char*> roles) {
    json u=currentUser(req); if(u.is_null()) return false;
    std::string role=u["role"].get<std::string>();
    for(auto r:roles) if(role==r) return true;
    return false;
}
static void requireRole(const httplib::Request& req, std::initializer_list<const char*> roles) {
    if(!hasRole(req,roles)) throw Forbidden("Your account does not have permission for this action");
}
static std::string sessionCookie(const std::string& token) {
    return "gehu_session="+token+"; Path=/; HttpOnly; SameSite=Lax; Max-Age=28800";
}

static int statusFor(CheckInResult r) {
    switch (r) {
        case CheckInResult::SUCCESS:          return 201;
        case CheckInResult::ALREADY_CHECKED_IN:        return 409;
        case CheckInResult::SESSION_FULL:     return 409;
        case CheckInResult::UNKNOWN_ATTENDEE: return 404;
        case CheckInResult::UNKNOWN_SESSION:  return 404;
        default:                              return 500;
    }
}

// 3-digit QR code (100-999). It is unique among all codes that are valid RIGHT NOW (event QR + class QR),
// so a code typed by a student identifies exactly one session / class.
static std::string newToken3() {
    conn().run("DELETE FROM qr_tokens WHERE expires_at<=datetime('now','-15 seconds')");
    conn().run("DELETE FROM class_qr_tokens WHERE expires_at<=datetime('now','-15 seconds')");
    std::random_device rd;
    for (int i = 0; i < 60; ++i) {
        std::string t = std::to_string(100 + rd() % 900);
        if (conn().query("SELECT 1 AS x FROM qr_tokens WHERE token=? UNION ALL SELECT 1 FROM class_qr_tokens WHERE token=?", {t, t}).empty()) return t;
    }
    throw Conflict("Could not generate a free QR code, please try again");
}
static const int QR_SECONDS = 10;   // a QR code is valid (and shown) for 10 seconds

static std::string findWebDir(const std::string& hint) {
    namespace fs = std::filesystem;
    for (const std::string& c : {hint, std::string("web"), std::string("../web"), std::string("../../web")})
        if (!c.empty() && fs::exists(fs::path(c) / "index.html")) return c;
    return "";
}

int main(int argc, char** argv) {
    int port = 8080, workers = 4;
    std::string host = "127.0.0.1", webHint;
    for (int i = 1; i + 1 < argc; i += 2) {
        std::string a = argv[i], v = argv[i + 1];
        if (a == "--port") port = std::stoi(v);
        else if (a == "--db") g_dbPath = v;
        else if (a == "--workers") workers = std::stoi(v);
        else if (a == "--host") host = v;
        else if (a == "--web") webHint = v;
    }
    try {
        Database db(g_dbPath);
        initSchema(db);
        bool seeded = seedIfEmpty(db);
        std::cout << "[db] " << g_dbPath << (seeded ? " (created and seeded with demo data)" : " (existing data kept)") << "\n";
        std::cout << "[db] integrity: " << verifyIntegrity(db).dump() << "\n";
    } catch (const std::exception& e) {
        std::cerr << "Database initialisation failed: " << e.what() << "\n";
        return 1;
    }
    g_pipeline = std::make_unique<Pipeline>(g_dbPath, workers);

    httplib::Server svr;
    g_server = &svr;
    svr.set_pre_routing_handler([](const httplib::Request& req, httplib::Response& res) {
        if (req.path.rfind("/api/",0)!=0 || req.path=="/api/auth/login" || req.path=="/api/health") return httplib::Server::HandlerResponse::Unhandled;
        json u=currentUser(req);
        if(u.is_null()) { sendJson(res,401,{{"error","Please log in first"}}); return httplib::Server::HandlerResponse::Handled; }
        const std::string role=u["role"].get<std::string>();
        if(role=="student") {
            bool ok=(req.path=="/api/auth/me" || req.path.rfind("/api/my/",0)==0 || req.path=="/api/events" || req.path=="/api/sessions" || (req.path=="/api/event-checkin" && req.method=="POST") || (req.path=="/api/class-checkin" && req.method=="POST"));
            if(!ok) { sendJson(res,403,{{"error","Students can only access their own attendance and approved event check-in"}}); return httplib::Server::HandlerResponse::Handled; }
        } else if(role=="teacher") {
            bool pathOk=(req.path=="/api/auth/me" || req.path=="/api/dashboard" || req.path=="/api/events" || req.path=="/api/sessions" || req.path=="/api/attendance" || req.path=="/api/class-attendance" || req.path=="/api/integrity" || req.path.rfind("/api/reports/",0)==0);
            bool teach=(req.path.rfind("/api/teacher/",0)==0);
            if(!teach && (req.method!="GET" || !pathOk)) { sendJson(res,403,{{"error","Teachers can take class attendance and view academic reports only"}}); return httplib::Server::HandlerResponse::Handled; }
        } else if(role=="organizer") {
            bool attendeeRead=(req.path=="/api/attendees" && req.method=="GET");
            bool pathOk=(req.path=="/api/auth/me" || req.path=="/api/dashboard" || req.path=="/api/events" || req.path.rfind("/api/events/",0)==0 || req.path=="/api/sessions" || req.path.rfind("/api/sessions/",0)==0 || req.path=="/api/topics" || req.path=="/api/checkin" || req.path=="/api/attendance" || req.path=="/api/integrity" || req.path.rfind("/api/reports/",0)==0 || attendeeRead);
            if(!pathOk) { sendJson(res,403,{{"error","Organizer account cannot access this administrative resource"}}); return httplib::Server::HandlerResponse::Handled; }
        }
        return httplib::Server::HandlerResponse::Unhandled;
    });

    // ---------- authentication ----------
    svr.Post("/api/auth/login", guarded([](const httplib::Request& req, httplib::Response& res) {
        json b=bodyJson(req); std::string username=val::reqStr(b,"username"), password=val::reqStr(b,"password");
        auto rows=conn().query("SELECT user_id,password_hash,active FROM app_users WHERE username=?",{username});
        if(rows.empty() || rows[0]["active"].get<int>()!=1 || !verifyPassword(password,rows[0]["password_hash"].get<std::string>())) { sendJson(res,401,{{"error","Invalid username or password"}}); return; }
        std::string token=randomToken(32);
        conn().run("INSERT INTO auth_sessions(token,user_id,expires_at) VALUES(?,?,datetime('now','+8 hours'))",{token,rows[0]["user_id"]});
        res.set_header("Set-Cookie",sessionCookie(token));
        auto me=conn().query("SELECT username,role,display_name,attendee_id FROM app_users WHERE user_id=?",{rows[0]["user_id"]});
        sendJson(res,200,me[0]);
    }));
    svr.Post("/api/auth/logout", guarded([](const httplib::Request& req, httplib::Response& res) { std::string t=cookieToken(req); if(!t.empty()) conn().run("DELETE FROM auth_sessions WHERE token=?",{t}); res.set_header("Set-Cookie","gehu_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0"); sendJson(res,200,{{"logged_out",true}}); }));
    svr.Get("/api/auth/me", guarded([](const httplib::Request& req, httplib::Response& res) { json u=currentUser(req); if(u.is_null()) { sendJson(res,401,{{"error","Not logged in"}}); return; } u.erase("user_id"); sendJson(res,200,u); }));
    svr.Get("/api/my/attendance", guarded([](const httplib::Request& req, httplib::Response& res) {
        requireRole(req,{"student"}); json u=currentUser(req); if(u.is_null() || u["attendee_id"].is_null()) throw NotFound("Student profile not linked");
        long long id=u["attendee_id"].get<long long>();
        auto events=conn().query("SELECT e.name AS event_name,s.title AS session_name,s.start_time,s.end_time,a.checkin_time,'EVENT PRESENT' AS status FROM attendance a JOIN sessions s ON s.session_id=a.session_id JOIN events e ON e.event_id=s.event_id WHERE a.attendee_id=? ORDER BY s.start_time DESC",{id});
        auto classes=conn().query("SELECT cs.class_name AS subject,cs.class_date,cs.start_time,cs.room,COALESCE(ca.status,'ABSENT') AS status,ca.marked_at FROM class_sessions cs LEFT JOIN class_attendance ca ON ca.class_session_id=cs.class_session_id AND ca.attendee_id=?1 WHERE cs.batch=(SELECT organization FROM attendees WHERE attendee_id=?1) AND cs.class_date<=date('now','localtime') ORDER BY cs.class_date DESC,cs.start_time DESC,cs.class_session_id DESC",{id});
        auto subjects=conn().query("SELECT cs.class_name AS subject,COUNT(*) AS total_classes,SUM(CASE WHEN ca.status IN ('PRESENT','PRESENT_VIA_APPROVED_EVENT') THEN 1 ELSE 0 END) AS present,ROUND(100.0*SUM(CASE WHEN ca.status IN ('PRESENT','PRESENT_VIA_APPROVED_EVENT') THEN 1 ELSE 0 END)/COUNT(*),1) AS percentage FROM class_sessions cs LEFT JOIN class_attendance ca ON ca.class_session_id=cs.class_session_id AND ca.attendee_id=?1 WHERE cs.batch=(SELECT organization FROM attendees WHERE attendee_id=?1) AND cs.class_date<=date('now','localtime') GROUP BY cs.class_name ORDER BY cs.class_name",{id});
        sendJson(res,200,{{"events",events},{"classes",classes},{"subjects",subjects}});
    }));

    // ---------- CLASS ATTENDANCE (teacher starts a class, student scans the 3-digit QR) ----------
    // 1) teacher starts a class for a subject (date/time = now)
    svr.Post("/api/teacher/classes", guarded([](const httplib::Request& req, httplib::Response& res) {
        requireRole(req,{"teacher","admin"}); json b=bodyJson(req);
        std::string name=val::reqStr(b,"class_name"), batch=val::optStr(b,"batch"), room=val::optStr(b,"room");
        if(batch.empty()) batch="B.Tech CSE - GEHU Dehradun";
        conn().run("INSERT INTO class_sessions(class_name,batch,class_date,start_time,end_time,room) VALUES(?,?,date('now','localtime'),strftime('%H:%M','now','localtime'),strftime('%H:%M','now','localtime','+1 hour'),?)",{name,batch,room});
        long long newCid=conn().lastInsertId();
        // students who ALREADY checked in to an event session overlapping this class time are present for this class too
        conn().run("INSERT OR IGNORE INTO class_attendance(class_session_id,attendee_id,status,source_event_id) "
                   "SELECT cs.class_session_id, at.attendee_id, 'PRESENT_VIA_APPROVED_EVENT', s.event_id "
                   "FROM class_sessions cs JOIN sessions s ON substr(s.start_time,1,10)=cs.class_date "
                   "AND cs.start_time<substr(s.end_time,12,5) AND cs.end_time>substr(s.start_time,12,5) "
                   "JOIN attendance at ON at.session_id=s.session_id JOIN attendees a ON a.attendee_id=at.attendee_id AND a.organization=cs.batch "
                   "WHERE cs.class_session_id=?",{newCid});
        sendJson(res,201,{{"class_session_id",newCid},{"class_name",name}});
    }));
    // 2) list of classes with present count
    svr.Get("/api/teacher/classes", guarded([](const httplib::Request& req, httplib::Response& res) {
        requireRole(req,{"teacher","admin"});
        sendJson(res,200,conn().query("SELECT cs.class_session_id,cs.class_name AS subject,cs.class_date,cs.start_time,cs.batch,"
            "(SELECT COUNT(*) FROM class_attendance ca WHERE ca.class_session_id=cs.class_session_id AND ca.status<>'ABSENT') AS present,"
            "(SELECT COUNT(*) FROM app_users u JOIN attendees a ON a.attendee_id=u.attendee_id WHERE u.role='student' AND u.active=1 AND a.organization=cs.batch) AS total_students "
            "FROM class_sessions cs ORDER BY cs.class_session_id DESC LIMIT 50"));
    }));
    // 3) the rotating 3-digit QR of one class (valid 10 s)
    svr.Get(R"(/api/teacher/classes/(\d+)/qr-token)", guarded([](const httplib::Request& req, httplib::Response& res) {
        requireRole(req,{"teacher","admin"}); int cid=idOf(req);
        auto c=conn().query("SELECT class_name FROM class_sessions WHERE class_session_id=?",{cid});
        if(c.empty()) throw NotFound("Class not found");
        std::string token=newToken3();
        conn().run("INSERT INTO class_qr_tokens(token,class_session_id,expires_at) VALUES(?,?,datetime('now','+10 seconds'))",{token,cid});
        sendJson(res,200,{{"token",token},{"class_id",cid},{"subject",c[0]["class_name"]},{"valid_for_seconds",QR_SECONDS}});
    }));
    // 4) who is present / absent in this class (roster = student accounts of the class batch)
    svr.Get(R"(/api/teacher/classes/(\d+)/attendance)", guarded([](const httplib::Request& req, httplib::Response& res) {
        requireRole(req,{"teacher","admin"});
        sendJson(res,200,conn().query("SELECT a.attendee_id,a.name AS student,a.attendee_code,COALESCE(ca.status,'ABSENT') AS status,ca.marked_at "
            "FROM app_users u JOIN attendees a ON a.attendee_id=u.attendee_id "
            "JOIN class_sessions cs ON cs.class_session_id=?1 AND a.organization=cs.batch "
            "LEFT JOIN class_attendance ca ON ca.class_session_id=cs.class_session_id AND ca.attendee_id=a.attendee_id "
            "WHERE u.role='student' AND u.active=1 ORDER BY a.name",{idOf(req)}));
    }));
    // 5) teacher marks a student manually (backup if a student's phone fails)
    svr.Post(R"(/api/teacher/classes/(\d+)/mark)", guarded([](const httplib::Request& req, httplib::Response& res) {
        requireRole(req,{"teacher","admin"}); json b=bodyJson(req); int cid=idOf(req);
        int aid=val::reqInt(b,"attendee_id"); std::string st=val::reqStr(b,"status");
        if(st!="PRESENT" && st!="ABSENT") throw ValidationError("status must be PRESENT or ABSENT");
        if(conn().query("SELECT 1 AS x FROM class_sessions WHERE class_session_id=?",{cid}).empty()) throw NotFound("Class not found");
        if(conn().query("SELECT 1 AS x FROM attendees WHERE attendee_id=?",{aid}).empty()) throw NotFound("Student not found");
        conn().run("INSERT INTO class_attendance(class_session_id,attendee_id,status) VALUES(?,?,?) ON CONFLICT(class_session_id,attendee_id) DO UPDATE SET status=excluded.status, source_event_id=NULL, marked_at=datetime('now','localtime')",{cid,aid,st});
        sendJson(res,200,{{"ok",true},{"status",st}});
    }));
    // 6) STUDENT scans the QR / types the 3-digit code -> attendance. Identity comes from the login, never from the request.
    svr.Post("/api/class-checkin", guarded([](const httplib::Request& req, httplib::Response& res) {
        requireRole(req,{"student"}); json u=currentUser(req), b=bodyJson(req);
        if(u["attendee_id"].is_null()) throw NotFound("Student profile not linked");
        std::string token=val::reqStr(b,"qr_token");
        auto c=conn().query("SELECT t.class_session_id,cs.class_name,cs.batch FROM class_qr_tokens t JOIN class_sessions cs ON cs.class_session_id=t.class_session_id WHERE t.token=? AND t.expires_at>datetime('now','-2 seconds')",{token});
        if(c.empty()) throw Conflict("Wrong or expired code. Enter the code currently shown on the teacher's screen.");
        auto me=conn().query("SELECT organization FROM attendees WHERE attendee_id=?",{u["attendee_id"]});
        if(me.empty() || me[0]["organization"]!=c[0]["batch"]) throw Forbidden("This class is not for your batch");
        int n=conn().run("INSERT OR IGNORE INTO class_attendance(class_session_id,attendee_id,status) VALUES(?,?,'PRESENT')",{c[0]["class_session_id"],u["attendee_id"]});
        std::string subject=c[0]["class_name"].get<std::string>();
        if(n==0) sendJson(res,200,{{"result","ALREADY_MARKED"},{"message","Your attendance for "+subject+" is already marked"},{"subject",subject}});
        else sendJson(res,201,{{"result","PRESENT"},{"message","Present! Attendance marked for "+subject},{"subject",subject}});
    }));

    // ---------- dashboard / health / integrity ----------
    svr.Get("/api/dashboard", guarded([](const httplib::Request&, httplib::Response& res) { sendJson(res, 200, Reports::dashboard(conn())); }));
    svr.Get("/api/health", guarded([](const httplib::Request&, httplib::Response& res) {
        sendJson(res, 200, {{"status", "ok"}, {"pipeline", g_pipeline->stats()}}); }));
    svr.Get("/api/integrity", guarded([](const httplib::Request&, httplib::Response& res) { sendJson(res, 200, verifyIntegrity(conn())); }));

    // ---------- events & topics ----------
    svr.Get("/api/events", guarded([](const httplib::Request&, httplib::Response& res) { sendJson(res, 200, Repository(conn()).listEvents()); }));
    svr.Post("/api/events", guarded([](const httplib::Request& req, httplib::Response& res) { requireRole(req,{"admin","organizer"}); json e=Repository(conn()).createEvent(bodyJson(req)); conn().run("INSERT OR REPLACE INTO event_approvals(event_id,status) VALUES(?,'APPROVED')",{e["event_id"]}); sendJson(res, 201, e); }));
    svr.Get(R"(/api/events/(\d+))", guarded([](const httplib::Request& req, httplib::Response& res) { sendJson(res, 200, Repository(conn()).getEvent(idOf(req))); }));
    svr.Put(R"(/api/events/(\d+))", guarded([](const httplib::Request& req, httplib::Response& res) { sendJson(res, 200, Repository(conn()).updateEvent(idOf(req), bodyJson(req))); }));
    svr.Delete(R"(/api/events/(\d+))", guarded([](const httplib::Request& req, httplib::Response& res) { Repository(conn()).deleteEvent(idOf(req)); sendJson(res, 200, {{"deleted", true}}); }));
    svr.Post(R"(/api/events/(\d+)/topics)", guarded([](const httplib::Request& req, httplib::Response& res) { sendJson(res, 201, Repository(conn()).addTopic(idOf(req), bodyJson(req))); }));
    svr.Get("/api/topics", guarded([](const httplib::Request& req, httplib::Response& res) { sendJson(res, 200, Repository(conn()).listTopics(intParam(req, "event_id"))); }));
    svr.Delete(R"(/api/topics/(\d+))", guarded([](const httplib::Request& req, httplib::Response& res) { Repository(conn()).deleteTopic(idOf(req)); sendJson(res, 200, {{"deleted", true}}); }));

    // ---------- event approval workflow ----------
    svr.Get("/api/approvals/pending", guarded([](const httplib::Request& req, httplib::Response& res) { requireRole(req,{"admin"}); sendJson(res,200,conn().query("SELECT e.event_id,e.name,e.location,e.start_date,e.end_date,ea.status FROM events e JOIN event_approvals ea ON ea.event_id=e.event_id WHERE ea.status='PENDING' ORDER BY e.start_date")); }));
    svr.Post(R"(/api/events/(\d+)/approve)", guarded([](const httplib::Request& req, httplib::Response& res) { requireRole(req,{"admin"}); int id=idOf(req); json u=currentUser(req); if(conn().run("UPDATE event_approvals SET status='APPROVED',approved_by=?,updated_at=datetime('now','localtime') WHERE event_id=?",{u["user_id"],id})==0) throw NotFound("Event approval record not found"); sendJson(res,200,{{"approved",true},{"event_id",id}}); }));

    // ---------- sessions ----------
    svr.Get("/api/sessions", guarded([](const httplib::Request& req, httplib::Response& res) { sendJson(res, 200, Repository(conn()).listSessions(intParam(req, "event_id"))); }));
    svr.Post("/api/sessions", guarded([](const httplib::Request& req, httplib::Response& res) { sendJson(res, 201, Repository(conn()).createSession(bodyJson(req))); }));
    svr.Get(R"(/api/sessions/(\d+))", guarded([](const httplib::Request& req, httplib::Response& res) { sendJson(res, 200, Repository(conn()).getSession(idOf(req))); }));
    svr.Put(R"(/api/sessions/(\d+))", guarded([](const httplib::Request& req, httplib::Response& res) { sendJson(res, 200, Repository(conn()).updateSession(idOf(req), bodyJson(req))); }));
    svr.Delete(R"(/api/sessions/(\d+))", guarded([](const httplib::Request& req, httplib::Response& res) { Repository(conn()).deleteSession(idOf(req)); sendJson(res, 200, {{"deleted", true}}); }));

    // ---------- attendees ----------
    svr.Get("/api/attendees", guarded([](const httplib::Request& req, httplib::Response& res) { sendJson(res, 200, Repository(conn()).listAttendees(req.get_param_value("q"))); }));
    svr.Post("/api/attendees", guarded([](const httplib::Request& req, httplib::Response& res) { sendJson(res, 201, Repository(conn()).registerAttendee(bodyJson(req))); }));
    svr.Get(R"(/api/attendees/(\d+))", guarded([](const httplib::Request& req, httplib::Response& res) { sendJson(res, 200, Repository(conn()).getAttendee(idOf(req))); }));
    svr.Put(R"(/api/attendees/(\d+))", guarded([](const httplib::Request& req, httplib::Response& res) { sendJson(res, 200, Repository(conn()).updateAttendee(idOf(req), bodyJson(req))); }));
    svr.Delete(R"(/api/attendees/(\d+))", guarded([](const httplib::Request& req, httplib::Response& res) { Repository(conn()).deleteAttendee(idOf(req)); sendJson(res, 200, {{"deleted", true}}); }));
    svr.Get(R"(/api/attendees/(\d+)/history)", guarded([](const httplib::Request& req, httplib::Response& res) { sendJson(res, 200, Reports::attendeeHistory(conn(), idOf(req))); }));

    // ---------- class attendance audit (teacher/admin) ----------
    svr.Get("/api/class-attendance", guarded([](const httplib::Request& req, httplib::Response& res) {
        requireRole(req,{"admin","teacher"});
        sendJson(res,200,conn().query("SELECT a.name AS student,cs.class_name,cs.class_date,cs.start_time,cs.end_time,cs.room,ca.status,e.name AS approved_event,ca.marked_at FROM class_attendance ca JOIN attendees a ON a.attendee_id=ca.attendee_id JOIN class_sessions cs ON cs.class_session_id=ca.class_session_id LEFT JOIN events e ON e.event_id=ca.source_event_id ORDER BY cs.class_date,cs.start_time,a.name"));
    }));

    // ---------- attendance + check-in ----------
    svr.Get("/api/attendance", guarded([](const httplib::Request& req, httplib::Response& res) {
        sendJson(res, 200, Repository(conn()).listAttendance(intParam(req, "session_id"), intParam(req, "attendee_id"), intParam(req, "limit", 500))); }));

    svr.Post("/api/checkin", guarded([](const httplib::Request& req, httplib::Response& res) {
        json b = bodyJson(req);
        ScanRequest sr;
        sr.code = val::reqStr(b, "code");
        sr.sessionId = val::reqInt(b, "session_id");
        sr.kioskId = val::optStr(b, "kiosk_id");
        if (sr.kioskId.empty()) sr.kioskId = "WEB-KIOSK";
        // this HTTP thread acts as a PRODUCER: it enqueues the scan and waits for a worker's answer
        ScanOutcome o = g_pipeline->submit(sr).get();
        sendJson(res, statusFor(o.result), {{"result", toString(o.result)}, {"message", o.message},
                                            {"attendee_name", o.attendeeName}, {"attendee_id", o.attendeeId}, {"session_id", sr.sessionId}});
    }));

    // ---------- rotating event QR (5-second validity) ----------
    svr.Get(R"(/api/sessions/(\d+)/qr-token)", guarded([](const httplib::Request& req, httplib::Response& res) {
        requireRole(req,{"admin","organizer"}); int sid=idOf(req);
        auto ok=conn().query("SELECT s.session_id,s.title,e.name AS event_name,ea.status FROM sessions s JOIN events e ON e.event_id=s.event_id LEFT JOIN event_approvals ea ON ea.event_id=e.event_id WHERE s.session_id=?",{sid});
        if(ok.empty()) throw NotFound("Session not found");
        std::string token=newToken3();
        conn().run("INSERT INTO qr_tokens(token,session_id,expires_at) VALUES(?,?,datetime('now','+10 seconds'))",{token,sid});
        sendJson(res,200,{{"token",token},{"session_id",sid},{"session",ok[0]["title"]},{"event",ok[0]["event_name"]},{"valid_for_seconds",QR_SECONDS}});
    }));
    svr.Post("/api/event-checkin", guarded([](const httplib::Request& req, httplib::Response& res) {
        requireRole(req,{"student"}); json u=currentUser(req), b=bodyJson(req);
        if(u["attendee_id"].is_null()) throw NotFound("Student profile not linked");
        std::string token=val::reqStr(b,"qr_token"); int sid=val::optInt(b,"session_id",0);
        // the 3-digit code identifies the session; session_id is optional (if sent it must match)
        auto valid=conn().query("SELECT session_id FROM qr_tokens WHERE token=?1 AND (?2=0 OR session_id=?2) AND expires_at>datetime('now','-2 seconds') ORDER BY expires_at DESC LIMIT 1",{token,sid});
        if(valid.empty()) throw Conflict("Wrong or expired code. Enter the code currently shown on the organizer's screen.");
        sid=valid[0]["session_id"].get<int>();
        auto a=conn().query("SELECT attendee_code FROM attendees WHERE attendee_id=?",{u["attendee_id"]});
        if(a.empty()) throw NotFound("Student attendee record not found");
        ScanOutcome o=g_pipeline->submit({a[0]["attendee_code"].get<std::string>(),sid,"STUDENT-QR"}).get();
        if(o.result==CheckInResult::SUCCESS) {
            conn().run("INSERT OR IGNORE INTO class_attendance(class_session_id,attendee_id,status,source_event_id) SELECT cs.class_session_id,?, 'PRESENT_VIA_APPROVED_EVENT', s.event_id FROM class_sessions cs JOIN sessions s ON s.session_id=? WHERE cs.batch=(SELECT organization FROM attendees WHERE attendee_id=?) AND cs.class_date=substr(s.start_time,1,10) AND cs.start_time<substr(s.end_time,12,5) AND cs.end_time>substr(s.start_time,12,5)",{u["attendee_id"],sid,u["attendee_id"]});
        }
        sendJson(res,statusFor(o.result),{{"result",toString(o.result)},{"message",o.message},{"attendee_name",o.attendeeName},{"session_id",sid}});
    }));

    // ---------- reports (JSON or CSV) ----------
    svr.Get(R"(/api/reports/([a-z]+))", guarded([](const httplib::Request& req, httplib::Response& res) {
        std::string type = req.matches[1];
        json rows = Reports::byType(conn(), type);
        if (req.get_param_value("format") == "csv") {
            res.set_header("Content-Disposition", "attachment; filename=\"" + type + "_report.csv\"");
            res.set_content(Reports::toCsv(rows), "text/csv");
        } else {
            sendJson(res, 200, rows);
        }
    }));

    // ---------- concurrency lab (uses disposable databases only) ----------
    svr.Post("/api/demo/concurrency", guarded([](const httplib::Request&, httplib::Response& res) {
        std::unique_lock<std::mutex> lk(g_demoMutex, std::try_to_lock);
        if (!lk.owns_lock()) { sendJson(res, 429, {{"error", "another demo is already running"}}); return; }
        sendJson(res, 200, runConcurrencyDemo());
    }));
    svr.Post("/api/demo/stress", guarded([](const httplib::Request& req, httplib::Response& res) {
        std::unique_lock<std::mutex> lk(g_demoMutex, std::try_to_lock);
        if (!lk.owns_lock()) { sendJson(res, 429, {{"error", "another demo is already running"}}); return; }
        int cfg = val::optInt(bodyJson(req), "config", 0);
        if (cfg < 0 || cfg > 4) throw ValidationError("config must be 0 (all) or 1..4");
        sendJson(res, 200, runStressSuite(cfg));
    }));

    svr.set_error_handler([](const httplib::Request& req, httplib::Response& res) {
        if (req.path.rfind("/api/", 0) == 0 && res.body.empty()) sendJson(res, res.status, {{"error", "no such endpoint"}});
    });

    std::string web = findWebDir(webHint);
    if (web.empty()) std::cerr << "[warn] web/ folder not found - only the REST API will work\n";
    else svr.set_mount_point("/", web);

    std::signal(SIGINT, [](int) { if (g_server) g_server->stop(); });
    std::cout << "[server] http://" << host << ":" << port << "  (workers: " << workers << ", web: " << (web.empty() ? "-" : web) << ")\n"
              << "[server] press Ctrl+C to stop\n";
    if (!svr.listen(host.c_str(), port)) std::cerr << "Could not listen on " << host << ":" << port << " (port in use?)\n";

    g_pipeline->shutdown();   // drain queued scans, join workers
    std::cout << "[server] stopped cleanly\n";
    return 0;
}
