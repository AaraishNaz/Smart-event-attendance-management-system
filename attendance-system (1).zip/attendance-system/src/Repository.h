// Repository.h - CRUD for events, topics, sessions, attendees (Modules 2, 3, 4).
// A Repository borrows ONE Database connection; create one per thread.
#pragma once
#include "Models.h"

class Repository {
public:
    explicit Repository(Database& db) : db_(db) {}

    // ---- events & topics ----
    json createEvent(const json& body);
    json updateEvent(int id, const json& body);
    void deleteEvent(int id);
    json listEvents();
    json getEvent(int id);
    json addTopic(int eventId, const json& body);
    json listTopics(int eventId);          // 0 = all events
    void deleteTopic(int id);

    // ---- sessions ----
    json createSession(const json& body);
    json updateSession(int id, const json& body);
    void deleteSession(int id);
    json listSessions(int eventId);        // 0 = all events
    json getSession(int id);

    // ---- attendees ----
    json registerAttendee(const json& body);
    json updateAttendee(int id, const json& body);
    void deleteAttendee(int id);
    json listAttendees(const std::string& search);
    json getAttendee(int id);

    // ---- attendance log ----
    json listAttendance(int sessionId, int attendeeId, int limit);

private:
    void checkSession(const Session& s, int ignoreId);
    Database& db_;
};
