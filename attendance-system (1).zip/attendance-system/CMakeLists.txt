cmake_minimum_required(VERSION 3.18)
project(SmartEventAttendance LANGUAGES C CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
if(NOT CMAKE_BUILD_TYPE)
  set(CMAKE_BUILD_TYPE Release)
endif()

# ---------------------------------------------------------------------------
# Third-party libraries are downloaded ONCE into third_party/ (needs internet at the first configure).
# If this fails, download the 4 files by hand - see README.md ("Manual dependency download").
# ---------------------------------------------------------------------------
set(TP ${CMAKE_SOURCE_DIR}/third_party)
file(MAKE_DIRECTORY ${TP} ${TP}/nlohmann)
function(fetch_file url dest)
  if(NOT EXISTS ${dest})
    message(STATUS "Downloading ${url}")
    file(DOWNLOAD ${url} ${dest} SHOW_PROGRESS STATUS st TLS_VERIFY ON)
    list(GET st 0 code)
    if(NOT code EQUAL 0)
      file(REMOVE ${dest})
      message(FATAL_ERROR "Download failed: ${url}\nSee README.md -> Manual dependency download")
    endif()
  endif()
endfunction()

fetch_file(https://raw.githubusercontent.com/yhirose/cpp-httplib/v0.15.3/httplib.h ${TP}/httplib.h)
fetch_file(https://github.com/nlohmann/json/releases/download/v3.11.3/json.hpp ${TP}/nlohmann/json.hpp)
if(NOT EXISTS ${TP}/sqlite3.c)
  fetch_file(https://www.sqlite.org/2024/sqlite-amalgamation-3460000.zip ${TP}/sqlite.zip)
  file(ARCHIVE_EXTRACT INPUT ${TP}/sqlite.zip DESTINATION ${TP}/_tmp)
  file(COPY ${TP}/_tmp/sqlite-amalgamation-3460000/sqlite3.c ${TP}/_tmp/sqlite-amalgamation-3460000/sqlite3.h DESTINATION ${TP})
  file(REMOVE_RECURSE ${TP}/_tmp)
  file(REMOVE ${TP}/sqlite.zip)
endif()

find_package(Threads REQUIRED)

# SQLite compiled from the amalgamation (no system installation needed)
add_library(sqlite3_lib STATIC ${TP}/sqlite3.c)
target_include_directories(sqlite3_lib PUBLIC ${TP})
target_compile_definitions(sqlite3_lib PRIVATE SQLITE_THREADSAFE=1 SQLITE_OMIT_LOAD_EXTENSION=1)

# all business logic lives in this library; the server and the tests both link it
add_library(attendance_core STATIC
  src/Database.cpp src/Models.cpp src/Schema.cpp src/Repository.cpp
  src/AttendanceEngine.cpp src/Pipeline.cpp src/Reports.cpp src/Workload.cpp src/Auth.cpp)
target_include_directories(attendance_core PUBLIC src ${TP})
target_link_libraries(attendance_core PUBLIC sqlite3_lib Threads::Threads)
if(WIN32)
  target_compile_definitions(attendance_core PUBLIC _WIN32_WINNT=0x0A00)
  target_link_libraries(attendance_core PUBLIC ws2_32 wsock32 bcrypt)
endif()
if(CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
  target_compile_options(attendance_core PRIVATE -Wall -Wextra)
endif()

add_executable(attendance_server src/main.cpp)
target_link_libraries(attendance_server PRIVATE attendance_core)

add_executable(run_tests tests/tests.cpp)
target_link_libraries(run_tests PRIVATE attendance_core)

# copy the web frontend next to the executable so "attendance_server" finds ./web
add_custom_command(TARGET attendance_server POST_BUILD
  COMMAND ${CMAKE_COMMAND} -E copy_directory ${CMAKE_SOURCE_DIR}/web $<TARGET_FILE_DIR:attendance_server>/web)

enable_testing()
add_test(NAME all_tests COMMAND run_tests)
