# GEHU Smart Attendance - Upgrade Notes

This update extends the existing C++17 + SQLite + cpp-httplib project. It does not connect to Graphic Era Hill University's production ERP.

## Included

- Login screen with student, teacher, organizer and admin roles.
- PBKDF2-HMAC-SHA256 password hashes on Windows (120,000 iterations), random session tokens, HttpOnly/SameSite cookies and 8-hour expiry.
- Four sample student identities: Aaraish Naz, Apoorva Singh, Harsh Tanwar and Aditi Mamgain.
- Organizer event creation; new events are pending until an administrator approves them.
- Organizer/admin QR display with server-generated random challenge tokens expiring after 3 seconds.
- Student login-bound event check-in; the server derives the attendee identity from the authenticated account.
- Existing unique attendance constraint, transaction-based attendance engine, scan audit log and worker-thread pipeline remain in place.
- Successful event check-in maps an overlapping scheduled class to `PRESENT_VIA_APPROVED_EVENT`, with a link to the approved event.
- Student personal attendance page and teacher/admin class synchronization audit.
- Existing concurrency lab and stress tests retained; password-hash and demo seed assertions added.

## Apply to the existing Windows project

1. Stop the running server with `Ctrl+C`.
2. Extract this ZIP into the existing `attendance-system` project root (the folder containing `CMakeLists.txt`). Choose **Replace files** when prompted.
3. Keep your existing `third_party` folder and `attendance.db` file. The update does not include dependencies or overwrite your database.
4. Open PowerShell in the project root and run:

   ```powershell
   $env:Path = "C:\msys64\ucrt64\bin;$env:Path"
   Remove-Item -Recurse -Force .\build -ErrorAction SilentlyContinue
   .\build.bat
   .\build\run_tests.exe
   .\build\attendance_server.exe
   ```

5. Open `http://localhost:8080`.

If you keep your old `attendance.db`, the startup migration creates the new tables and adds the four sample student accounts without deleting existing records. If you want a completely fresh demo database, stop the server and rename `attendance.db` before starting again.

## Demo accounts

| Role | Username | Password |
|---|---|---|
| Student | `aaraish` | `Student@123` |
| Student | `apoorva` | `Student@123` |
| Student | `harsh` | `Student@123` |
| Student | `aditi` | `Student@123` |
| Teacher | `teacher` | `Teacher@123` |
| Organizer | `organizer` | `Organizer@123` |
| Admin | `admin` | `Admin@123` |

## Demo sequence

1. Sign in as `organizer`; create an event and its sessions. New events show `PENDING`.
2. Sign out and sign in as `admin`; open **Event Approvals** and approve the event.
3. Sign in as `organizer`; open **Live QR Display**, select the session and display the changing QR.
4. Sign in as one of the sample students in another browser/device, open **My Attendance**, scan the QR with a supported browser camera or paste the current token and submit.
5. The student sees the event attendance and, if a class slot overlaps and matches the sample batch, `PRESENT_VIA_APPROVED_EVENT` in class attendance.
6. Sign in as `teacher`; open **Reports** to inspect the attendance log and class synchronization audit.

## Important limitations

- The 3-second rotating QR reduces screenshot reuse but cannot fully stop live relaying during its validity window.
- Browser camera QR detection requires a supported browser and a secure context (localhost is generally treated as secure). For a phone on the same network, deploy behind HTTPS rather than exposing the local demo server directly.
- The event-to-class mapping is a local demo record, not an update to GEHU ERP. Actual ERP synchronization requires authorized university APIs, identity mapping, timetable rules and approval.
- Before any real deployment, replace demo passwords, configure HTTPS and Secure cookies, add login rate limiting and CSRF protection, review access policies, and perform a security review.

## November 2026 UI upgrade
- Added a role-first sign-in screen with Student, Teacher, Organizer and Admin selection cards.
- Login still authenticates against the existing server-side account database; the selected role is checked against the authenticated account and mismatches are signed out with a clear message.
- Existing dashboards, REST API, SQLite schema and concurrency engine are retained.
- Teacher permissions remain read-only in this version. The teacher dashboard exposes the existing academic attendance/report views; creating class sessions or taking regular classroom attendance is not yet implemented.
- Verified a fresh Linux CMake build and the existing automated suite: 94 checks passed, 0 failed.
