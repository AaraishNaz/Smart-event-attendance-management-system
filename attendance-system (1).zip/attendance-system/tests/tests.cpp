// tests.cpp - self-contained test runner (Module 12). Build target: run_tests
// Every test uses its own disposable database file; nothing touches attendance.db.
#include "AttendanceEngine.h"
#include "Auth.h"
#include "Pipeline.h"
#include "Repository.h"
#include "ScanQueue.h"
#include "Schema.h"
#include "Workload.h"
#include <atomic>
#include <functional>
#include <iomanip>
#include <iostream>
#include <thread>

static int g_pass = 0, g_fail = 0;
#define CHECK(c) do { if (c) ++g_pass; else { ++g_fail; std::cout << "    FAIL: " #c "  (line " << __LINE__ << ")\n"; } } while (0)
#define CHECK_THROWS(T, ...) do { bool ok_ = false; try { __VA_ARGS__; } catch (const T&) { ok_ = true; } catch (...) {} CHECK(ok_); } while (0)

struct TempDb {
    std::string path;
    explicit TempDb(const char* tag) : path(tempDbPath(tag)) {}
    ~TempDb() { removeDbFiles(path); }
};

struct Fixture {            // a fresh database with one event + helpers
    TempDb tmp;
    Database db;
    Repository repo;
    int eventId = 0;
    explicit Fixture(const char* tag) : tmp(tag), db(tmp.path), repo(db) {
        initSchema(db);
        eventId = repo.createEvent({{"name", "Test Event"}, {"location", "Hall"}, {"start_date", "2026-01-01"},
                                    {"end_date", "2026-01-02"}, {"topics", {"A", "B"}}})["event_id"].get<int>();
    }
    int session(int cap, const std::string& room = "R1", const std::string& st = "2026-01-01 10:00", const std::string& en = "2026-01-01 11:00") {
        return repo.createSession({{"event_id", eventId}, {"title", "S-" + room}, {"room", room}, {"start_time", st},
                                   {"end_time", en}, {"capacity", cap}})["session_id"].get<int>();
    }
    std::string attendee(int n) {   // returns the generated ATT-xxxx code
        return repo.registerAttendee({{"name", "Person " + std::to_string(n)}, {"email", "p" + std::to_string(n) + "@x.com"}})["attendee_code"].get<std::string>();
    }
};

static CheckInResult scan(Database& db, const std::string& code, int sid) { return AttendanceEngine::checkIn(db, {code, sid, "T"}).result; }

// ------------------------------------------------------------------ tests
static void test_database() {
    Fixture f("db");
    json t = f.db.query("SELECT name FROM sqlite_master WHERE type='table' AND name IN ('events','topics','sessions','attendees','attendance','scan_log')");
    CHECK(t.size() == 6);
    CHECK_THROWS(DbError, f.db.run("INSERT INTO sessions(event_id,title,room,start_time,end_time,capacity) VALUES(999,'x','r','a','b',5)"));   // FK
    CHECK_THROWS(DbError, f.db.run("INSERT INTO sessions(event_id,title,room,start_time,end_time,capacity) VALUES(1,'x','r','a','b',0)"));     // CHECK
    CHECK(verifyIntegrity(f.db)["ok"].get<bool>());
    TempDb seeded("seed");
    Database d2(seeded.path);
    initSchema(d2);
    CHECK(seedIfEmpty(d2));
    CHECK(!seedIfEmpty(d2));                                   // second call must not duplicate data
    CHECK(d2.query("SELECT COUNT(*) AS c FROM attendees")[0]["c"].get<int>() == 4);
    CHECK(d2.query("SELECT COUNT(*) AS c FROM app_users")[0]["c"].get<int>() == 7);
    CHECK(d2.query("SELECT COUNT(*) AS c FROM class_sessions")[0]["c"].get<int>() == 1);
    CHECK(d2.query("SELECT COUNT(*) AS c FROM event_approvals WHERE status='APPROVED'")[0]["c"].get<int>() == 1);
    CHECK(d2.query("SELECT COUNT(*) AS c FROM sessions")[0]["c"].get<int>() == 6);
    CHECK(verifyIntegrity(d2)["ok"].get<bool>());
    {   // transaction rollback
        Tx tx(d2);
        d2.run("DELETE FROM scan_log");
    }                                                          // no commit -> rolled back
    CHECK(d2.query("SELECT COUNT(*) AS c FROM scan_log")[0]["c"].get<int>() > 0);
}

static void test_auth_passwords() {
    std::string h=makePasswordHash("Student@123");
    CHECK(h.find('$')!=std::string::npos);
    CHECK(verifyPassword("Student@123",h));
    CHECK(!verifyPassword("wrong-password",h));
}

static void test_attendees() {
    Fixture f("att");
    std::string c1 = f.attendee(1), c2 = f.attendee(2);
    json a1 = f.repo.getAttendee(1), a2 = f.repo.getAttendee(2);
    CHECK(c1 != c2);
    CHECK(a1["qr_code"] != a2["qr_code"]);
    CHECK(a1["qr_code"].get<std::string>().rfind("QR-", 0) == 0);
    CHECK(f.repo.listAttendees("Person 2").size() == 1);
    CHECK(f.repo.listAttendees("").size() == 2);
    CHECK(f.repo.updateAttendee(1, {{"name", "Renamed"}, {"email", "new@x.com"}})["name"] == "Renamed");
    CHECK_THROWS(Conflict, f.repo.registerAttendee({{"name", "Dup"}, {"email", "p2@x.com"}}));
    CHECK_THROWS(ValidationError, f.repo.registerAttendee({{"name", "Bad"}, {"email", "not-an-email"}}));
    CHECK_THROWS(ValidationError, f.repo.registerAttendee({{"email", "a@b.com"}}));
    int sid = f.session(5);
    scan(f.db, c1, sid);
    CHECK_THROWS(Conflict, f.repo.deleteAttendee(1));          // has attendance -> protected
    f.repo.deleteAttendee(2);                                  // no attendance -> allowed
    CHECK_THROWS(NotFound, f.repo.getAttendee(2));
}

static void test_events_sessions() {
    Fixture f("ev");
    int s1 = f.session(10, "R1");
    CHECK_THROWS(Conflict, f.session(10, "R1", "2026-01-01 10:30", "2026-01-01 11:30"));   // same room overlaps
    int s2 = f.session(10, "R2", "2026-01-01 10:00", "2026-01-01 11:00");                  // parallel session in another room is fine
    CHECK(s1 != s2);
    CHECK_THROWS(ValidationError, f.session(0, "R3"));
    CHECK_THROWS(ValidationError, f.session(5, "R3", "2026-01-01 12:00", "2026-01-01 11:00"));
    CHECK(f.repo.getEvent(f.eventId)["topics"].size() == 2);
    CHECK(f.repo.updateEvent(f.eventId, {{"name", "Test Event 2"}, {"location", "New Hall"}, {"start_date", "2026-01-01"}, {"end_date", "2026-01-03"}})["location"] == "New Hall");
    CHECK(f.repo.listSessions(f.eventId).size() == 2);
    CHECK(f.repo.getSession(s1)["remaining"].get<int>() == 10);
    std::string code = f.attendee(1);
    scan(f.db, code, s1);
    CHECK_THROWS(Conflict, f.repo.deleteEvent(f.eventId));
    CHECK_THROWS(Conflict, f.repo.deleteSession(s1));
    f.repo.deleteSession(s2);
}

static void test_checkin() {
    Fixture f("ci");
    int sid = f.session(2);
    std::string a1 = f.attendee(1), a2 = f.attendee(2), a3 = f.attendee(3);
    CHECK(scan(f.db, a1, sid) == CheckInResult::SUCCESS);
    CHECK(scan(f.db, a1, sid) == CheckInResult::ALREADY_CHECKED_IN);
    CHECK(scan(f.db, "  " + a2 + "\n", sid) == CheckInResult::SUCCESS);          // whitespace/newline from a USB scanner
    CHECK(scan(f.db, a3, sid) == CheckInResult::SESSION_FULL);                   // capacity 2 reached
    CHECK(scan(f.db, "ATT-9999", sid) == CheckInResult::UNKNOWN_ATTENDEE);
    CHECK(scan(f.db, a3, 9999) == CheckInResult::UNKNOWN_SESSION);
    std::string qr = f.repo.getAttendee(1)["qr_code"].get<std::string>();
    CHECK(scan(f.db, qr, sid) == CheckInResult::ALREADY_CHECKED_IN);                      // QR payload identifies the same attendee
    std::string lower = a2; for (auto& c : lower) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    CHECK(scan(f.db, lower, sid) == CheckInResult::ALREADY_CHECKED_IN);                   // manual entry is case-insensitive
    CHECK(f.db.query("SELECT COUNT(*) AS c FROM attendance")[0]["c"].get<int>() == 2);
    CHECK(f.db.query("SELECT COUNT(*) AS c FROM scan_log")[0]["c"].get<int>() == 8);
    CHECK(f.db.query("SELECT COUNT(*) AS c FROM scan_log WHERE result='DUPLICATE'")[0]["c"].get<int>() == 3);
}

static void test_capacity_multithreaded() {   // 8 threads, every attendee scanned by every thread
    Fixture f("cap");
    const int CAP = 50, N = 200, T = 8;
    int sid = f.session(CAP);
    std::vector<std::string> codes;
    for (int i = 1; i <= N; ++i) codes.push_back(f.attendee(i));
    std::atomic<int> ok{0}, dup{0}, full{0}, err{0};
    std::vector<std::thread> ts;
    for (int t = 0; t < T; ++t)
        ts.emplace_back([&] {
            Database db(f.tmp.path);                     // one connection per thread
            for (const auto& c : codes) {
                switch (scan(db, c, sid)) {
                    case CheckInResult::SUCCESS: ++ok; break;
                    case CheckInResult::ALREADY_CHECKED_IN: ++dup; break;
                    case CheckInResult::SESSION_FULL: ++full; break;
                    default: ++err;
                }
            }
        });
    for (auto& t : ts) t.join();
    CHECK(ok == CAP);                                    // exactly CAP successes - never overbooked
    CHECK(err == 0);
    CHECK(ok + dup + full == N * T);                     // every scan accounted for
    CHECK(f.db.query("SELECT COUNT(*) AS c FROM attendance")[0]["c"].get<int>() == CAP);
    CHECK(verifyIntegrity(f.db)["ok"].get<bool>());
}

static void test_queue() {
    ScanQueue<int> q;
    CHECK(q.push(1)); CHECK(q.push(2)); CHECK(q.push(3));
    q.close();
    int v = 0;
    CHECK(!q.push(4));                                   // closed queue rejects new work
    CHECK(q.pop(v) && v == 1); CHECK(q.pop(v) && v == 2); CHECK(q.pop(v) && v == 3);   // drained in order
    CHECK(!q.pop(v));                                    // closed + empty -> false
    ScanQueue<int> q2;                                   // a blocked consumer must wake up when the queue closes
    std::atomic<bool> woke{false};
    std::thread consumer([&] { int x; woke = !q2.pop(x); });
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    q2.close();
    consumer.join();
    CHECK(woke);
}

static void test_pipeline_shutdown() {
    Fixture f("pipe");
    int sid = f.session(1000);
    std::vector<std::string> codes;
    for (int i = 1; i <= 100; ++i) codes.push_back(f.attendee(i));
    std::vector<std::future<ScanOutcome>> futs;
    {
        Pipeline p(f.tmp.path, 3);
        for (const auto& c : codes) futs.push_back(p.submit({c, sid, "K"}));
        p.shutdown();                                    // must DRAIN all 100 queued scans before returning
        CHECK(p.stats()["processed"].get<int>() == 100);
        CHECK(p.submit({codes[0], sid, "K"}).get().result == CheckInResult::DATABASE_ERROR);   // rejected after close
    }
    int ok = 0;
    for (auto& fu : futs) ok += fu.get().result == CheckInResult::SUCCESS;
    CHECK(ok == 100);
    CHECK(f.db.query("SELECT COUNT(*) AS c FROM attendance")[0]["c"].get<int>() == 100);
}

static void test_concurrency_demo() {
    json d = runConcurrencyDemo();
    const json& s = d["safe"]; const json& u = d["unsafe"];
    CHECK(s["overbooked_by"].get<int>() == 0);
    CHECK(s["duplicate_rows"].get<int>() == 0);
    CHECK(s["lost_scans"].get<int>() == 0);
    CHECK(s["integrity_ok"].get<bool>());
    std::cout << "    SAFE   : rows=" << s["attendance_rows"] << " capacity=" << d["capacity"] << " overbooked_by=" << s["overbooked_by"]
              << " duplicates=" << s["duplicate_rows"] << "\n"
              << "    UNSAFE : rows=" << u["attendance_rows"] << " capacity=" << d["capacity"] << " overbooked_by=" << u["overbooked_by"]
              << " duplicates=" << u["duplicate_rows"] << "   (race conditions vary from run to run)\n";
}

static void test_stress() {
    json all = runStressSuite();
    const int expectedScans[] = {120, 600, 1200, 5000};
    std::cout << "    " << std::left << std::setw(42) << "workload" << std::right << std::setw(7) << "scans" << std::setw(9) << "success"
              << std::setw(7) << "dup" << std::setw(9) << "rejected" << std::setw(7) << "dberr" << std::setw(9) << "sec" << std::setw(11) << "scans/s" << "  integrity\n";
    for (size_t i = 0; i < all.size(); ++i) {
        const json& r = all[i];
        auto L = [&](const char* k) { return r[k].get<long long>(); };
        std::cout << "    " << std::left << std::setw(42) << r["name"].get<std::string>() << std::right << std::setw(7) << L("total_scans")
                  << std::setw(9) << L("successful") << std::setw(7) << L("duplicates") << std::setw(9) << L("rejected")
                  << std::setw(7) << L("database_errors") << std::setw(9) << std::fixed << std::setprecision(3) << r["seconds"].get<double>()
                  << std::setw(11) << std::setprecision(0) << r["throughput_per_sec"].get<double>() << "  " << (r["integrity_ok"].get<bool>() ? "OK" : "BROKEN") << "\n";
        CHECK(r["total_scans"].get<int>() == expectedScans[i]);
        CHECK(r["lost_scans"].get<int>() == 0);
        CHECK(r["database_errors"].get<int>() == 0);
        CHECK(r["overbooked_by"].get<int>() == 0);
        CHECK(r["integrity_ok"].get<bool>());
        CHECK(r["successful"].get<int>() + r["duplicates"].get<int>() + r["rejected"].get<int>() == expectedScans[i]);
    }
}

int main() {
    const std::vector<std::pair<const char*, std::function<void()>>> tests = {
        {"database (schema, FK, CHECK, seed, rollback)", test_database},
        {"authentication password hashing", test_auth_passwords},
        {"attendees (register, search, update, delete)", test_attendees},
        {"events & sessions (validation, room overlap)", test_events_sessions},
        {"check-in (all 6 results, duplicates, QR/ID)", test_checkin},
        {"capacity under 8 racing threads", test_capacity_multithreaded},
        {"scan queue (close, drain, wake-up)", test_queue},
        {"pipeline shutdown (no lost scans)", test_pipeline_shutdown},
        {"concurrency lab (safe vs unsafe)", test_concurrency_demo},
        {"stress workloads (4 configurations)", test_stress}};
    for (const auto& t : tests) {
        std::cout << "[ RUN ] " << t.first << "\n";
        int before = g_fail;
        try { t.second(); }
        catch (const std::exception& e) { ++g_fail; std::cout << "    EXCEPTION: " << e.what() << "\n"; }
        std::cout << (g_fail == before ? "[  OK ] " : "[FAIL ] ") << t.first << "\n";
    }
    std::cout << "\nchecks passed: " << g_pass << ", failed: " << g_fail << "\n";
    return g_fail ? 1 : 0;
}
