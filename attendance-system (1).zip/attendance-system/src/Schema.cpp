#include "Schema.h"
#include "Auth.h"
#include "Repository.h"
#include "AttendanceEngine.h"
#include <cctype>
#include <cstdio>
#include <map>

const char* SESSION_STATS_SQL =
    "SELECT *, capacity - checked_in AS remaining, "
    "ROUND(100.0 * checked_in / capacity, 1) AS utilization_pct FROM v_session_stats";

static const char* SCHEMA_SQL = R"SQL(
CREATE TABLE IF NOT EXISTS events (
    event_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL UNIQUE,
    location    TEXT NOT NULL,
    start_date  TEXT NOT NULL,
    end_date    TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS topics (
    topic_id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id INTEGER NOT NULL REFERENCES events(event_id) ON DELETE CASCADE,
    name     TEXT NOT NULL,
    UNIQUE (event_id, name)
);
CREATE TABLE IF NOT EXISTS sessions (
    session_id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id   INTEGER NOT NULL REFERENCES events(event_id) ON DELETE CASCADE,
    topic_id   INTEGER REFERENCES topics(topic_id) ON DELETE SET NULL,
    title      TEXT NOT NULL,
    room       TEXT NOT NULL,
    start_time TEXT NOT NULL,
    end_time   TEXT NOT NULL,
    capacity   INTEGER NOT NULL CHECK (capacity > 0)
);
CREATE TABLE IF NOT EXISTS attendees (
    attendee_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    attendee_code TEXT NOT NULL UNIQUE,      -- human readable ID, e.g. ATT-0012 (manual entry)
    qr_code       TEXT NOT NULL UNIQUE,      -- payload printed in the QR code, e.g. QR-9F3A...
    name          TEXT NOT NULL,
    email         TEXT NOT NULL UNIQUE,
    phone         TEXT NOT NULL DEFAULT '',
    organization  TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS attendance (
    attendance_id INTEGER PRIMARY KEY AUTOINCREMENT,
    attendee_id   INTEGER NOT NULL REFERENCES attendees(attendee_id) ON DELETE CASCADE,
    session_id    INTEGER NOT NULL REFERENCES sessions(session_id)   ON DELETE CASCADE,
    checkin_time  TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    kiosk_id      TEXT NOT NULL DEFAULT '',
    UNIQUE (attendee_id, session_id)         -- last line of defence against duplicate attendance
);
-- Extra audit table: EVERY scan (also rejected ones) is logged, so duplicate statistics are real.
CREATE TABLE IF NOT EXISTS scan_log (
    scan_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id   INTEGER,
    scanned_code TEXT,
    result       TEXT NOT NULL,
    kiosk_id     TEXT,
    scan_time    TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_attendance_session  ON attendance(session_id);
CREATE INDEX IF NOT EXISTS idx_attendance_attendee ON attendance(attendee_id);
CREATE INDEX IF NOT EXISTS idx_sessions_event      ON sessions(event_id);
CREATE INDEX IF NOT EXISTS idx_sessions_topic      ON sessions(topic_id);
CREATE INDEX IF NOT EXISTS idx_topics_event        ON topics(event_id);
CREATE INDEX IF NOT EXISTS idx_scanlog_session     ON scan_log(session_id, result);
CREATE TABLE IF NOT EXISTS app_users (
    user_id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('admin','teacher','organizer','student')),
    display_name TEXT NOT NULL,
    attendee_id INTEGER REFERENCES attendees(attendee_id) ON DELETE SET NULL,
    active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1))
);
CREATE TABLE IF NOT EXISTS auth_sessions (
    token TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES app_users(user_id) ON DELETE CASCADE,
    expires_at TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS event_approvals (
    event_id INTEGER PRIMARY KEY REFERENCES events(event_id) ON DELETE CASCADE,
    status TEXT NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING','APPROVED','REJECTED')),
    approved_by INTEGER REFERENCES app_users(user_id),
    updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS qr_tokens (
    token TEXT PRIMARY KEY,
    session_id INTEGER NOT NULL REFERENCES sessions(session_id) ON DELETE CASCADE,
    expires_at TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS class_sessions (
    class_session_id INTEGER PRIMARY KEY AUTOINCREMENT,
    class_name TEXT NOT NULL,
    batch TEXT NOT NULL,
    class_date TEXT NOT NULL,
    start_time TEXT NOT NULL,
    end_time TEXT NOT NULL,
    room TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS class_attendance (
    class_attendance_id INTEGER PRIMARY KEY AUTOINCREMENT,
    class_session_id INTEGER NOT NULL REFERENCES class_sessions(class_session_id) ON DELETE CASCADE,
    attendee_id INTEGER NOT NULL REFERENCES attendees(attendee_id) ON DELETE CASCADE,
    status TEXT NOT NULL CHECK(status IN ('PRESENT','PRESENT_VIA_APPROVED_EVENT','ABSENT')),
    source_event_id INTEGER REFERENCES events(event_id),
    marked_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    UNIQUE(class_session_id, attendee_id)
);
CREATE TABLE IF NOT EXISTS class_qr_tokens (
    token TEXT NOT NULL,
    class_session_id INTEGER NOT NULL REFERENCES class_sessions(class_session_id) ON DELETE CASCADE,
    expires_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_class_qr_token ON class_qr_tokens(token, expires_at);
CREATE INDEX IF NOT EXISTS idx_auth_sessions_expiry ON auth_sessions(expires_at);
CREATE INDEX IF NOT EXISTS idx_qr_tokens_expiry ON qr_tokens(expires_at);
CREATE INDEX IF NOT EXISTS idx_class_date ON class_sessions(class_date, start_time);
CREATE VIEW IF NOT EXISTS v_session_stats AS
SELECT s.session_id, s.event_id, s.topic_id, s.title, s.room, s.start_time, s.end_time, s.capacity,
       e.name AS event_name,
       COALESCE(t.name, '(no topic)') AS topic_name,
       (SELECT COUNT(*) FROM attendance a WHERE a.session_id = s.session_id) AS checked_in,
       (SELECT COUNT(*) FROM scan_log l WHERE l.session_id = s.session_id AND l.result = 'DUPLICATE') AS duplicate_scans
FROM sessions s
JOIN events e ON e.event_id = s.event_id
LEFT JOIN topics t ON t.topic_id = s.topic_id;
)SQL";

void initSchema(Database& db) { db.exec(SCHEMA_SQL); }

static void seedDemoAccounts(Database& db) {
    Repository repo(db);
    const char* names[] = {"Aaraish Naz", "Apoorva Singh", "Harsh Tanwar", "Aditi Mamgain"};
    const char* emails[] = {"aaraish@gehu.demo", "apoorva@gehu.demo", "harsh@gehu.demo", "aditi@gehu.demo"};
    const char* usernames[] = {"aaraish", "apoorva", "harsh", "aditi"};
    for (int i=0;i<4;++i) {
        long long aid=0;
        auto found=db.query("SELECT attendee_id FROM attendees WHERE email=?",{emails[i]});
        if (found.empty()) {
            json a=repo.registerAttendee({{"name",names[i]},{"email",emails[i]},
                {"phone","900000000"+std::to_string(i+1)},{"organization","B.Tech CSE - GEHU Dehradun"}});
            aid=a["attendee_id"].get<long long>();
        } else aid=found[0]["attendee_id"].get<long long>();
        if (db.query("SELECT 1 AS x FROM app_users WHERE username=?",{usernames[i]}).empty())
            db.run("INSERT INTO app_users(username,password_hash,role,display_name,attendee_id) VALUES(?,?,'student',?,?)",
                   {usernames[i],makePasswordHash("Student@123"),names[i],aid});
    }
    if (db.query("SELECT 1 AS x FROM app_users WHERE username='admin'").empty()) db.run("INSERT INTO app_users(username,password_hash,role,display_name) VALUES(?,?,?,?)",{"admin",makePasswordHash("Admin@123"),"admin","GEHU Administrator"});
    if (db.query("SELECT 1 AS x FROM app_users WHERE username='teacher'").empty()) db.run("INSERT INTO app_users(username,password_hash,role,display_name) VALUES(?,?,?,?)",{"teacher",makePasswordHash("Teacher@123"),"teacher","Demo Faculty"});
    if (db.query("SELECT 1 AS x FROM app_users WHERE username='organizer'").empty()) db.run("INSERT INTO app_users(username,password_hash,role,display_name) VALUES(?,?,?,?)",{"organizer",makePasswordHash("Organizer@123"),"organizer","Event Organizer"});
    if (db.query("SELECT COUNT(*) AS c FROM class_sessions")[0]["c"].get<long long>()==0)
        db.run("INSERT INTO class_sessions(class_name,batch,class_date,start_time,end_time,room) VALUES(?,?,?,?,?,?)",
               {"Data Structures", "B.Tech CSE - GEHU Dehradun", "2026-11-20", "10:00", "12:00", "CSE Block - Room 204"});
    db.exec("INSERT OR IGNORE INTO event_approvals(event_id,status) SELECT event_id,'APPROVED' FROM events;");
    db.exec("UPDATE event_approvals SET status='APPROVED' WHERE status<>'APPROVED';");   // admin approval step was removed
}

bool seedIfEmpty(Database& db) {
    if (db.query("SELECT COUNT(*) AS c FROM events")[0]["c"].get<long long>() > 0) { seedDemoAccounts(db); return false; }
    Repository repo(db);
    json ev = repo.createEvent({{"name", "TechFest 2026"}, {"location", "Main Campus Auditorium Complex"},
                                {"start_date", "2026-11-20"}, {"end_date", "2026-11-21"},
                                {"description", "Annual college technology festival with parallel sessions"},
                                {"topics", {"C++ & Systems", "Web Development", "Databases", "Artificial Intelligence"}}});
    int eid = ev["event_id"].get<int>();
    std::map<std::string, int> topic;
    for (auto& t : ev["topics"]) topic[t["name"].get<std::string>()] = t["topic_id"].get<int>();

    struct S { const char* title; const char* topic; const char* room; const char* st; const char* en; int cap; };
    const S sessions[] = {
        {"C++ Programming Workshop",  "C++ & Systems",         "Lab 1",    "2026-11-20 10:00", "2026-11-20 12:00", 30},
        {"Web Development Bootcamp",  "Web Development",       "Lab 2",    "2026-11-20 10:00", "2026-11-20 12:00", 25},
        {"SQL Masterclass",           "Databases",             "Room 101", "2026-11-20 10:00", "2026-11-20 12:00", 20},
        {"AI & Machine Learning Talk","Artificial Intelligence","Hall A",   "2026-11-20 10:00", "2026-11-20 12:00", 40},
        {"Multithreading Deep Dive",  "C++ & Systems",         "Lab 1",    "2026-11-20 14:00", "2026-11-20 16:00", 15},
        {"REST API Workshop",         "Web Development",       "Lab 2",    "2026-11-20 14:00", "2026-11-20 16:00", 20}};
    std::vector<int> sid;
    for (const S& s : sessions) {
        json r = repo.createSession({{"event_id", eid}, {"topic_id", topic[s.topic]}, {"title", s.title}, {"room", s.room},
                                     {"start_time", s.st}, {"end_time", s.en}, {"capacity", s.cap}});
        sid.push_back(r["session_id"].get<int>());
    }
    seedDemoAccounts(db);
    // Keep the four sample students unmarked so the live QR workflow can be demonstrated end-to-end.
    db.run("INSERT INTO scan_log(session_id,scanned_code,result,kiosk_id) VALUES(?,?,?,?)",{sid[0],"DEMO-INVALID","UNKNOWN_ATTENDEE","SEED"});
    return true;
}

json verifyIntegrity(Database& db) {
    json r;
    std::string ic = db.query("PRAGMA integrity_check")[0]["integrity_check"].get<std::string>();
    long long fk  = static_cast<long long>(db.query("PRAGMA foreign_key_check").size());
    long long dup = db.query("SELECT COUNT(*) AS c FROM (SELECT attendee_id, session_id FROM attendance "
                             "GROUP BY attendee_id, session_id HAVING COUNT(*) > 1)")[0]["c"].get<long long>();
    long long over = db.query("SELECT COUNT(*) AS c FROM v_session_stats WHERE checked_in > capacity")[0]["c"].get<long long>();
    r["sqlite_integrity_check"] = ic;
    r["foreign_key_violations"] = fk;
    r["duplicate_attendance_rows"] = dup;
    r["overbooked_sessions"] = over;
    r["ok"] = (ic == "ok" && fk == 0 && dup == 0 && over == 0);
    return r;
}
