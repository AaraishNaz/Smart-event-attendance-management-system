#include "Reports.h"
#include "Schema.h"
#include <sstream>

namespace Reports {
namespace {
long long one(Database& db, const std::string& sql) { return db.query(sql)[0]["c"].get<long long>(); }
}

json dashboard(Database& db) {
    json d;
    d["totals"] = {
        {"events",     one(db, "SELECT COUNT(*) AS c FROM events")},
        {"attendees",  one(db, "SELECT COUNT(*) AS c FROM attendees")},
        {"sessions",   one(db, "SELECT COUNT(*) AS c FROM sessions")},
        {"checkins",   one(db, "SELECT COUNT(*) AS c FROM attendance")},
        {"duplicates", one(db, "SELECT COUNT(*) AS c FROM scan_log WHERE result='DUPLICATE'")},
        {"total_scans", one(db, "SELECT COUNT(*) AS c FROM scan_log")},
        {"total_capacity", one(db, "SELECT COALESCE(SUM(capacity),0) AS c FROM sessions")},
        {"remaining_capacity", one(db, "SELECT COALESCE(SUM(capacity - checked_in),0) AS c FROM v_session_stats")}};
    long long cap = d["totals"]["total_capacity"].get<long long>();
    d["totals"]["attendance_pct"] = cap ? static_cast<double>(d["totals"]["checkins"].get<long long>()) * 100.0 / cap : 0.0;
    d["sessions"] = db.query(std::string(SESSION_STATS_SQL) + " ORDER BY start_time, session_id");
    d["topics"] = byType(db, "topics");
    d["rooms"] = byType(db, "rooms");
    d["scan_results"] = db.query("SELECT result, COUNT(*) AS count FROM scan_log GROUP BY result ORDER BY count DESC");
    d["recent"] = db.query(
        "SELECT a.checkin_time, p.name AS attendee_name, s.title AS session_title, s.room "
        "FROM attendance a JOIN attendees p ON p.attendee_id=a.attendee_id JOIN sessions s ON s.session_id=a.session_id "
        "ORDER BY a.attendance_id DESC LIMIT 10");
    return d;
}

json byType(Database& db, const std::string& type) {
    if (type == "sessions")
        return db.query(std::string("SELECT session_id, event_name, topic_name, title, room, start_time, end_time, capacity, "
                                    "checked_in, remaining, utilization_pct, duplicate_scans FROM (") + SESSION_STATS_SQL +
                        ") ORDER BY start_time, session_id");
    if (type == "capacity")
        return db.query(std::string("SELECT session_id, title, room, capacity, checked_in, remaining, utilization_pct, "
                                    "CASE WHEN remaining<=0 THEN 'FULL' WHEN utilization_pct>=80 THEN 'ALMOST FULL' ELSE 'AVAILABLE' END AS status FROM (") +
                        SESSION_STATS_SQL + ") ORDER BY utilization_pct DESC");
    if (type == "topics")
        return db.query("SELECT topic_name, COUNT(*) AS sessions, SUM(checked_in) AS checkins, SUM(capacity) AS capacity, "
                        "ROUND(100.0*SUM(checked_in)/SUM(capacity),1) AS attendance_pct FROM v_session_stats "
                        "GROUP BY topic_id, topic_name ORDER BY checkins DESC");
    if (type == "rooms")
        return db.query("SELECT room, COUNT(*) AS sessions, SUM(checked_in) AS checkins, SUM(capacity) AS capacity, "
                        "ROUND(100.0*SUM(checked_in)/SUM(capacity),1) AS attendance_pct FROM v_session_stats "
                        "GROUP BY room ORDER BY checkins DESC");
    if (type == "events")
        return db.query(
            "SELECT e.event_id, e.name, e.location, e.start_date, e.end_date, "
            "(SELECT COUNT(*) FROM sessions s WHERE s.event_id=e.event_id) AS sessions, "
            "(SELECT COUNT(*) FROM attendance a JOIN sessions s ON s.session_id=a.session_id WHERE s.event_id=e.event_id) AS checkins, "
            "(SELECT COUNT(DISTINCT a.attendee_id) FROM attendance a JOIN sessions s ON s.session_id=a.session_id WHERE s.event_id=e.event_id) AS unique_attendees, "
            "(SELECT COUNT(*) FROM attendees) AS registered_attendees, "
            "ROUND(100.0*(SELECT COUNT(DISTINCT a.attendee_id) FROM attendance a JOIN sessions s ON s.session_id=a.session_id WHERE s.event_id=e.event_id)"
            "/MAX((SELECT COUNT(*) FROM attendees),1),1) AS attendance_pct FROM events e ORDER BY e.start_date");
    if (type == "duplicates")
        return db.query(
            "SELECT s.session_id, s.title, s.room, COUNT(*) AS total_scans, "
            "SUM(l.result='SUCCESS') AS successful, SUM(l.result='DUPLICATE') AS duplicates, "
            "SUM(l.result='SESSION_FULL') AS full_rejections, SUM(l.result IN ('UNKNOWN_ATTENDEE','UNKNOWN_SESSION')) AS unknown, "
            "ROUND(100.0*SUM(l.result='DUPLICATE')/COUNT(*),1) AS duplicate_rate_pct "
            "FROM scan_log l JOIN sessions s ON s.session_id=l.session_id GROUP BY s.session_id ORDER BY duplicates DESC, s.session_id");
    if (type == "attendance")
        return db.query(
            "SELECT a.attendance_id, a.checkin_time, p.attendee_code, p.name AS attendee_name, s.title AS session_title, s.room, "
            "e.name AS event_name, a.kiosk_id FROM attendance a JOIN attendees p ON p.attendee_id=a.attendee_id "
            "JOIN sessions s ON s.session_id=a.session_id JOIN events e ON e.event_id=s.event_id ORDER BY a.attendance_id");
    throw NotFound("Unknown report type '" + type + "'");
}

json attendeeHistory(Database& db, int attendeeId) {
    json who = db.query("SELECT attendee_id, attendee_code, name, email FROM attendees WHERE attendee_id=?", {attendeeId});
    if (who.empty()) throw NotFound("Attendee not found");
    json h;
    h["attendee"] = who[0];
    h["history"] = db.query(
        "SELECT a.checkin_time, s.title AS session_title, s.room, s.start_time, e.name AS event_name "
        "FROM attendance a JOIN sessions s ON s.session_id=a.session_id JOIN events e ON e.event_id=s.event_id "
        "WHERE a.attendee_id=? ORDER BY a.checkin_time", {attendeeId});
    return h;
}

static std::string cell(const json& v) {
    if (v.is_null()) return "";
    std::string s = v.is_string() ? v.get<std::string>() : v.dump();
    if (s.find_first_of(",\"\n\r") != std::string::npos) {
        std::string q = "\"";
        for (char c : s) { if (c == '"') q += '"'; q += c; }
        s = q + "\"";
    }
    return s;
}

std::string toCsv(const json& rows) {
    if (!rows.is_array() || rows.empty()) return "no data\n";
    std::ostringstream o;
    bool first = true;
    for (auto it = rows[0].begin(); it != rows[0].end(); ++it) { if (!first) o << ','; o << cell(it.key()); first = false; }
    o << "\r\n";
    for (const auto& r : rows) {
        first = true;
        for (auto it = r.begin(); it != r.end(); ++it) { if (!first) o << ','; o << cell(it.value()); first = false; }
        o << "\r\n";
    }
    return o.str();
}
}  // namespace Reports
