#include "Models.h"
#include <algorithm>
#include <regex>

namespace val {
std::string trim(const std::string& s) {
    size_t a = s.find_first_not_of(" \t\r\n");
    if (a == std::string::npos) return "";
    size_t b = s.find_last_not_of(" \t\r\n");
    return s.substr(a, b - a + 1);
}
std::string upper(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return static_cast<char>(std::toupper(c)); });
    return s;
}
std::string reqStr(const json& b, const char* key) {
    if (!b.is_object() || !b.contains(key) || !b.at(key).is_string())
        throw ValidationError(std::string("'") + key + "' is required");
    std::string s = trim(b.at(key).get<std::string>());
    if (s.empty()) throw ValidationError(std::string("'") + key + "' must not be empty");
    if (s.size() > 200) throw ValidationError(std::string("'") + key + "' is too long");
    return s;
}
std::string optStr(const json& b, const char* key) {
    return (b.is_object() && b.contains(key) && b.at(key).is_string()) ? trim(b.at(key).get<std::string>()) : "";
}
int reqInt(const json& b, const char* key) {
    if (!b.is_object() || !b.contains(key) || b.at(key).is_null())
        throw ValidationError(std::string("'") + key + "' is required");
    const json& v = b.at(key);
    if (v.is_number_integer()) return v.get<int>();
    if (v.is_string()) {
        try {
            std::string s = trim(v.get<std::string>());
            size_t pos = 0;
            int x = std::stoi(s, &pos);
            if (pos == s.size()) return x;
        } catch (...) {}
    }
    throw ValidationError(std::string("'") + key + "' must be an integer");
}
int optInt(const json& b, const char* key, int def) {
    if (!b.is_object() || !b.contains(key) || b.at(key).is_null()) return def;
    if (b.at(key).is_string() && trim(b.at(key).get<std::string>()).empty()) return def;
    return reqInt(b, key);
}
std::string reqDate(const json& b, const char* key) {
    std::string s = reqStr(b, key);
    if (!std::regex_match(s, std::regex(R"(\d{4}-\d{2}-\d{2})")))
        throw ValidationError(std::string("'") + key + "' must look like YYYY-MM-DD");
    return s;
}
std::string reqDateTime(const json& b, const char* key) {
    std::string s = reqStr(b, key);
    std::replace(s.begin(), s.end(), 'T', ' ');
    if (!std::regex_match(s, std::regex(R"(\d{4}-\d{2}-\d{2} \d{2}:\d{2})")))
        throw ValidationError(std::string("'") + key + "' must look like YYYY-MM-DD HH:MM");
    return s;
}
}  // namespace val

Event Event::fromRequest(const json& b) {
    Event e;
    e.name = val::reqStr(b, "name");
    e.location = val::reqStr(b, "location");
    e.startDate = val::reqDate(b, "start_date");
    e.endDate = val::reqDate(b, "end_date");
    e.description = val::optStr(b, "description");
    if (e.endDate < e.startDate) throw ValidationError("end_date must not be before start_date");
    if (b.contains("topics") && b["topics"].is_array())
        for (const auto& t : b["topics"])
            if (t.is_string() && !val::trim(t.get<std::string>()).empty()) e.topics.push_back(val::trim(t.get<std::string>()));
    return e;
}

Session Session::fromRequest(const json& b) {
    Session s;
    s.eventId = val::reqInt(b, "event_id");
    s.topicId = val::optInt(b, "topic_id", 0);
    s.title = val::reqStr(b, "title");
    s.room = val::reqStr(b, "room");
    s.startTime = val::reqDateTime(b, "start_time");
    s.endTime = val::reqDateTime(b, "end_time");
    s.capacity = val::reqInt(b, "capacity");
    if (s.endTime <= s.startTime) throw ValidationError("end_time must be after start_time");
    if (s.capacity < 1 || s.capacity > 100000) throw ValidationError("capacity must be between 1 and 100000");
    return s;
}

Attendee Attendee::fromRequest(const json& b) {
    Attendee a;
    a.name = val::reqStr(b, "name");
    a.email = val::reqStr(b, "email");
    a.phone = val::optStr(b, "phone");
    a.organization = val::optStr(b, "organization");
    if (!std::regex_match(a.email, std::regex(R"([^@\s]+@[^@\s]+\.[^@\s]+)"))) throw ValidationError("'email' is not a valid address");
    return a;
}
