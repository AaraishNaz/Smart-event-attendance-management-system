#include "AttendanceEngine.h"
#include "Models.h"

namespace {
ScanOutcome decide(Database& db, const std::string& code, const ScanRequest& r) {
    ScanOutcome o;
    json s = db.query("SELECT capacity, title FROM sessions WHERE session_id=?", {r.sessionId});
    if (s.empty()) { o.result = CheckInResult::UNKNOWN_SESSION; o.message = "This kiosk is not linked to a valid session"; return o; }

    json a = db.query("SELECT attendee_id, name FROM attendees WHERE qr_code=?1 OR attendee_code=?1", {code});
    if (a.empty()) { o.result = CheckInResult::UNKNOWN_ATTENDEE; o.message = "No attendee matches this QR code / ID"; return o; }
    o.attendeeId = a[0]["attendee_id"].get<long long>();
    o.attendeeName = a[0]["name"].get<std::string>();
    std::string title = s[0]["title"].get<std::string>();

    if (!db.query("SELECT 1 AS x FROM attendance WHERE attendee_id=? AND session_id=?", {o.attendeeId, r.sessionId}).empty()) {
        o.result = CheckInResult::ALREADY_CHECKED_IN; o.message = o.attendeeName + " is already checked in to " + title; return o;
    }
    long long used = db.query("SELECT COUNT(*) AS c FROM attendance WHERE session_id=?", {r.sessionId})[0]["c"].get<long long>();
    if (used >= s[0]["capacity"].get<long long>()) {
        o.result = CheckInResult::SESSION_FULL; o.message = title + " is full"; return o;
    }
    try {
        db.run("INSERT INTO attendance(attendee_id, session_id, kiosk_id) VALUES(?,?,?)", {o.attendeeId, r.sessionId, r.kioskId});
    } catch (const DbError& e) {
        if (e.code == SQLITE_CONSTRAINT_UNIQUE) {   // safety net: the UNIQUE(attendee_id, session_id) constraint fired
            o.result = CheckInResult::ALREADY_CHECKED_IN; o.message = o.attendeeName + " is already checked in to " + title; return o;
        }
        throw;
    }
    o.result = CheckInResult::SUCCESS;
    o.message = "Welcome, " + o.attendeeName + "! Checked in to " + title;
    return o;
}
}  // namespace

ScanOutcome AttendanceEngine::checkIn(Database& db, const ScanRequest& req) {
    const std::string code = val::upper(val::trim(req.code));   // scanners append '\n'; people type lower case
    try {
        Tx tx(db);   // BEGIN IMMEDIATE: we own the write lock from here until COMMIT, so nobody can sneak in
        ScanOutcome out = decide(db, code, req);
        db.run("INSERT INTO scan_log(session_id, scanned_code, result, kiosk_id) VALUES(?,?,?,?)",
               {req.sessionId, code, toString(out.result), req.kioskId});
        tx.commit();
        return out;
    } catch (const DbError& e) {   // Tx destructor has already rolled back
        ScanOutcome out;
        out.result = CheckInResult::DATABASE_ERROR;
        out.message = e.what();
        return out;
    }
}
