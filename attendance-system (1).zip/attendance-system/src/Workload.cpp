#include "Workload.h"
#include "AttendanceEngine.h"
#include "Pipeline.h"
#include "Schema.h"
#include <atomic>
#include <chrono>
#include <cstdio>
#include <filesystem>
#include <random>
#include <thread>

namespace fs = std::filesystem;
using Clock = std::chrono::steady_clock;

std::string tempDbPath(const std::string& tag) {
    static std::atomic<int> counter{0};
    auto stamp = std::chrono::duration_cast<std::chrono::milliseconds>(Clock::now().time_since_epoch()).count();
    fs::path p = fs::temp_directory_path() / ("attendance_" + tag + "_" + std::to_string(stamp) + "_" + std::to_string(counter++) + ".db");
    return p.string();
}

void removeDbFiles(const std::string& path) {
    std::error_code ec;
    for (const char* ext : {"", "-wal", "-shm"}) fs::remove(path + ext, ec);
}

namespace {
std::string attendeeCode(int n) { char b[32]; std::snprintf(b, sizeof b, "QR-TEST-%05d", n); return b; }

double secondsSince(Clock::time_point t0) { return std::chrono::duration<double>(Clock::now() - t0).count(); }

// the same random scan plan is used by the safe and unsafe runs, so the comparison is fair
std::vector<int> makePlan(int attendees, int scans, unsigned seed) {
    std::mt19937 rng(seed);
    std::vector<int> plan(scans);
    for (int& a : plan) a = static_cast<int>(rng() % attendees) + 1;
    return plan;
}

// Fill a fresh database with 1 event, N attendees, S sessions (fast bulk insert in one transaction).
std::vector<int> prepare(const std::string& path, int attendees, int sessions, int capacity) {
    Database db(path);
    initSchema(db);
    Tx tx(db);
    db.run("INSERT INTO events(name,location,start_date,end_date) VALUES('Stress Event','Lab','2026-01-01','2026-01-01')");
    for (int i = 1; i <= attendees; ++i) {
        std::string code = attendeeCode(i);
        db.run("INSERT INTO attendees(attendee_code,qr_code,name,email) VALUES(?,?,?,?)",
               {"ID-" + std::to_string(i), code, "Tester " + std::to_string(i), "t" + std::to_string(i) + "@test.com"});
    }
    std::vector<int> ids;
    for (int s = 1; s <= sessions; ++s) {
        db.run("INSERT INTO sessions(event_id,title,room,start_time,end_time,capacity) VALUES(1,?,?,?,?,?)",
               {"Session " + std::to_string(s), "Room " + std::to_string(s), "2026-01-01 10:00", "2026-01-01 11:00", capacity});
        ids.push_back(static_cast<int>(db.lastInsertId()));
    }
    tx.commit();
    return ids;
}

json verify(const std::string& path) {
    Database db(path);
    json v = verifyIntegrity(db);
    v["scan_log_rows"] = db.query("SELECT COUNT(*) AS c FROM scan_log")[0]["c"];
    v["attendance_rows"] = db.query("SELECT COUNT(*) AS c FROM attendance")[0]["c"];
    v["duplicate_rows"] = v["duplicate_attendance_rows"];
    v["overbooked_by"] = db.query("SELECT COALESCE(SUM(MAX(checked_in - capacity, 0)),0) AS c FROM v_session_stats")[0]["c"];
    return v;
}
}  // namespace

json runWorkload(const WorkloadConfig& cfg) {
    const int sessions = cfg.sessions > 0 ? cfg.sessions : cfg.kiosks;
    const int capacity = cfg.capacity > 0 ? cfg.capacity : (cfg.attendees + sessions - 1) / sessions;
    const std::string path = tempDbPath("run");
    json out;
    {
        std::vector<int> sessionIds = prepare(path, cfg.attendees, sessions, capacity);
        std::vector<int> plan = makePlan(cfg.attendees, cfg.scans, 42);
        Pipeline pipe(path, cfg.workers);

        std::vector<std::vector<ScanOutcome>> results(cfg.kiosks);
        std::vector<std::thread> kiosks;
        std::atomic<bool> go{false};
        for (int k = 0; k < cfg.kiosks; ++k)
            kiosks.emplace_back([&, k] {                       // each kiosk = one PRODUCER thread
                std::vector<std::future<ScanOutcome>> pending;
                while (!go.load()) std::this_thread::yield();
                for (int i = k; i < cfg.scans; i += cfg.kiosks)
                    pending.push_back(pipe.submit({attendeeCode(plan[i]), sessionIds[k % sessions], "KIOSK-" + std::to_string(k + 1)}));
                for (auto& f : pending) results[k].push_back(f.get());
            });
        auto t0 = Clock::now();
        go = true;
        for (auto& t : kiosks) t.join();
        double secs = secondsSince(t0);
        pipe.shutdown();                                       // close + drain + join workers

        long long c[6] = {0, 0, 0, 0, 0, 0}, total = 0;
        for (auto& v : results) for (auto& o : v) { c[static_cast<int>(o.result)]++; ++total; }
        json v = verify(path);
        out = {{"name", cfg.name}, {"kiosks", cfg.kiosks}, {"workers", cfg.workers}, {"attendees", cfg.attendees},
               {"sessions", sessions}, {"capacity_per_session", capacity}, {"total_scans", total},
               {"successful", c[0]}, {"duplicates", c[1]}, {"rejected", c[2] + c[3] + c[4]}, {"session_full", c[4]},
               {"database_errors", c[5]}, {"seconds", secs}, {"throughput_per_sec", secs > 0 ? total / secs : 0.0},
               {"scan_log_rows", v["scan_log_rows"]}, {"lost_scans", cfg.scans - v["scan_log_rows"].get<long long>()},
               {"attendance_rows", v["attendance_rows"]}, {"overbooked_by", v["overbooked_by"]},
               {"duplicate_rows", v["duplicate_rows"]}, {"integrity_ok", v["ok"]}};
    }
    removeDbFiles(path);
    return out;
}

// ---------------- UNSAFE version: deliberately WRONG (check-then-act without a transaction) ----------------
static json runUnsafe(int capacity, int attendees, int scans, int threads) {
    const std::string path = tempDbPath("unsafe");
    json out;
    {
        {   // a different schema: NO UNIQUE constraint and NO atomic transaction - this is the point of the demo
            Database db(path);
            db.exec("CREATE TABLE sessions(session_id INTEGER PRIMARY KEY, capacity INTEGER);"
                    "CREATE TABLE attendance(id INTEGER PRIMARY KEY AUTOINCREMENT, attendee_id INTEGER, session_id INTEGER);");
            db.run("INSERT INTO sessions VALUES(1, ?)", {capacity});
        }
        std::vector<int> plan = makePlan(attendees, scans, 42);
        std::atomic<bool> go{false};
        std::vector<std::thread> ts;
        for (int t = 0; t < threads; ++t)
            ts.emplace_back([&, t] {
                Database db(path);                               // own connection per thread, but NO locking logic
                while (!go.load()) std::this_thread::yield();
                for (int i = t; i < scans; i += threads) {
                    int a = plan[i];
                    long long used = db.query("SELECT COUNT(*) AS c FROM attendance WHERE session_id=1")[0]["c"].get<long long>();
                    bool dup = !db.query("SELECT 1 AS x FROM attendance WHERE attendee_id=? AND session_id=1", {a}).empty();
                    if (!dup && used < capacity) {
                        std::this_thread::sleep_for(std::chrono::microseconds(300));   // window where other threads act on stale data
                        try { db.run("INSERT INTO attendance(attendee_id,session_id) VALUES(?,1)", {a}); } catch (const DbError&) {}
                    }
                }
            });
        auto t0 = Clock::now();
        go = true;
        for (auto& t : ts) t.join();
        double secs = secondsSince(t0);
        Database db(path);
        long long rows = db.query("SELECT COUNT(*) AS c FROM attendance")[0]["c"].get<long long>();
        long long distinct = db.query("SELECT COUNT(DISTINCT attendee_id) AS c FROM attendance")[0]["c"].get<long long>();
        out = {{"attendance_rows", rows}, {"capacity", capacity}, {"overbooked_by", rows > capacity ? rows - capacity : 0},
               {"duplicate_rows", rows - distinct}, {"seconds", secs}, {"integrity_ok", rows <= capacity && rows == distinct}};
    }
    removeDbFiles(path);
    return out;
}

json runConcurrencyDemo(int capacity, int attendees, int scans, int threads) {
    WorkloadConfig w;
    w.name = "safe"; w.kiosks = threads; w.workers = 4; w.attendees = attendees; w.scans = scans; w.sessions = 1; w.capacity = capacity;
    json safe = runWorkload(w);
    json unsafe = runUnsafe(capacity, attendees, scans, threads);
    return {{"capacity", capacity}, {"attendees", attendees}, {"scans", scans}, {"threads", threads},
            {"safe", safe}, {"unsafe", unsafe}};
}

json runStressSuite(int only) {
    const WorkloadConfig cfgs[] = {{"3 kiosks / 2 workers / 100 attendees", 3, 2, 100, 120, 0, 0},
                                   {"6 kiosks / 4 workers / 500 attendees", 6, 4, 500, 600, 0, 0},
                                   {"10 kiosks / 8 workers / 1000 attendees", 10, 8, 1000, 1200, 0, 0},
                                   {"20 kiosks / 10 workers / 5000 scans", 20, 10, 1000, 5000, 0, 50}};
    json all = json::array();
    for (int i = 0; i < 4; ++i)
        if (only == 0 || only == i + 1) all.push_back(runWorkload(cfgs[i]));
    return all;
}
