// Workload.h - kiosk simulation, stress tests and the SAFE-vs-UNSAFE concurrency demo (Modules 11 and 12).
// Everything here uses a DISPOSABLE temporary database - production data is never touched.
#pragma once
#include "Database.h"
#include <string>

struct WorkloadConfig {
    std::string name = "workload";
    int kiosks = 3, workers = 2, attendees = 100, scans = 120;
    int sessions = 0;   // 0 -> one session per kiosk
    int capacity = 0;   // 0 -> ceil(attendees / sessions)
};

std::string tempDbPath(const std::string& tag);
void removeDbFiles(const std::string& path);

json runWorkload(const WorkloadConfig& cfg);                    // producers -> queue -> workers -> SQLite, verified afterwards
json runConcurrencyDemo(int capacity = 10, int attendees = 40, int scans = 160, int threads = 8);  // safe vs unsafe
json runStressSuite(int only = 0);                              // the 4 workloads of the project statement (only=1..4 runs one)
