#!/usr/bin/env bash
set -e
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
echo "Run tests:    ./build/run_tests"
echo "Start server: ./build/attendance_server   -> http://localhost:8080"
