// Database.h - thin RAII wrapper around ONE SQLite connection.
// RULE OF THE PROJECT: a Database object is never shared between threads.
// Every worker thread / HTTP thread owns its own connection (see docs/EXPLAIN.md).
#pragma once
#include <sqlite3.h>
#include <nlohmann/json.hpp>
#include <stdexcept>
#include <string>
#include <vector>

using json = nlohmann::json;

// ---- exception types (the REST layer maps them to HTTP status codes) ----
struct DbError : std::runtime_error {          // -> 500
    int code;                                  // SQLite extended error code
    DbError(const std::string& m, int c) : std::runtime_error(m), code(c) {}
};
struct ValidationError : std::runtime_error { using std::runtime_error::runtime_error; }; // -> 400
struct NotFound        : std::runtime_error { using std::runtime_error::runtime_error; }; // -> 404
struct Forbidden       : std::runtime_error { using std::runtime_error::runtime_error; }; // -> 403
struct Conflict        : std::runtime_error { using std::runtime_error::runtime_error; }; // -> 409

class Database {
public:
    explicit Database(const std::string& path);
    ~Database();
    Database(const Database&) = delete;
    Database& operator=(const Database&) = delete;

    void exec(const std::string& sql);                                   // no parameters, no result
    json query(const std::string& sql, const std::vector<json>& p = {}); // SELECT -> array of row objects
    int  run(const std::string& sql, const std::vector<json>& p = {});   // INSERT/UPDATE/DELETE -> rows changed
    long long lastInsertId() const { return sqlite3_last_insert_rowid(db_); }

    void begin(bool immediate = true); // BEGIN IMMEDIATE grabs the write lock right away
    void commit();
    void rollback() noexcept;          // safe to call at any time

private:
    [[noreturn]] void fail(const char* ctx, sqlite3_stmt* st = nullptr);
    sqlite3* db_ = nullptr;
    bool inTx_ = false;
};

// RAII transaction: rolls back automatically unless commit() was called.
class Tx {
public:
    explicit Tx(Database& d, bool immediate = true) : db_(d) { db_.begin(immediate); }
    void commit() { db_.commit(); done_ = true; }
    ~Tx() { if (!done_) db_.rollback(); }
    Tx(const Tx&) = delete;
    Tx& operator=(const Tx&) = delete;
private:
    Database& db_;
    bool done_ = false;
};
