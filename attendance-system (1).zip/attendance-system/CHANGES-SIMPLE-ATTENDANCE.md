# Simple class attendance - what changed

Files changed: src/main.cpp, src/Schema.cpp, web/index.html, web/app.js, web/style.css (no new source files, CMake unchanged).

Flow: Teacher login -> "Take Attendance" -> type subject -> Start class -> screen shows QR + big 3-digit code (changes every 10 s).
Student login -> "My Attendance" -> type the 3-digit code (or scan with camera) -> PRESENT.
Student portal shows subject-wise %, present/total, below-75% warning. Teacher sees live roster and can mark manually.
Event QR (organizer) also uses a 3-digit code / 10 s now.

New API: POST/GET /api/teacher/classes, GET /api/teacher/classes/{id}/qr-token, GET /api/teacher/classes/{id}/attendance,
POST /api/teacher/classes/{id}/mark, POST /api/class-checkin (student); /api/my/attendance now also returns "subjects".
New table class_qr_tokens is created automatically on startup; existing attendance.db is kept.

## Update 2: event QR fix + admin removed
* Event check-in: student types ONLY the 3-digit code (Session ID no longer needed; the code identifies the session).
* Codes are accepted for 5 extra seconds after they change (no more "expired" at the boundary); old codes are rejected after that.
* Organizer screen shows the 3-digit code in big text.
* Admin portal removed from the login page and menu. Events created by the organizer are approved automatically.

## Update 3: exact 10-second refresh
* The code/QR on the teacher and organizer screens is now refreshed by the on-screen countdown itself (exactly every 10 s, always in sync with the counter).
* Grace period after a code changes reduced from 5 s to 2 s (only to cover network delay).

## Update 4: event attendance also marks the overlapping class
* If a student checks in to an event session (organizer code) whose time overlaps a class (same date, same batch), the class is marked PRESENT (via event) automatically.
* Works in both orders: class started first, or event check-in first and the teacher starts the class later.
* A student already marked by the teacher keeps that status.
