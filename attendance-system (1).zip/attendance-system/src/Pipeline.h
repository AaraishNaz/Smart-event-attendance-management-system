// Pipeline.h - producer-consumer architecture (Module 6)
//
//   Kiosk threads / HTTP threads (producers) --submit()--> ScanQueue --> N worker threads (consumers) --> SQLite
//
// * every worker owns its OWN sqlite connection (opened inside the worker thread),
// * submit() returns a std::future so a kiosk can wait for the result (std::promise/future pair),
// * shutdown() closes the queue, lets workers DRAIN what is left, then joins them.
#pragma once
#include "AttendanceEngine.h"
#include "ScanQueue.h"
#include <atomic>
#include <future>
#include <thread>
#include <vector>

struct ScanJob {
    ScanRequest req;
    std::promise<ScanOutcome> result;
};

class Pipeline {
public:
    Pipeline(std::string dbPath, int workers);
    ~Pipeline() { shutdown(); }
    Pipeline(const Pipeline&) = delete;
    Pipeline& operator=(const Pipeline&) = delete;

    std::future<ScanOutcome> submit(ScanRequest req);   // called by producers (any thread)
    void shutdown();                                    // close queue, drain, join workers
    json stats() const;                                 // counters (atomics) + queue length

private:
    void workerLoop(int id);
    std::string dbPath_;
    ScanQueue<ScanJob> queue_;
    std::vector<std::thread> workers_;
    std::atomic<long long> processed_{0};
    std::atomic<long long> counts_[6]{};
};
