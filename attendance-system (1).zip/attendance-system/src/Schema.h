// Schema.h - database creation, seeding and integrity verification (Module 1)
#pragma once
#include "Database.h"

void initSchema(Database& db);            // CREATE TABLE / INDEX / VIEW (idempotent)
bool seedIfEmpty(Database& db);           // demo event, topics, sessions, attendees, a few scans
json verifyIntegrity(Database& db);       // PRAGMA integrity_check + our own business rules

// Base query used everywhere for session occupancy / remaining seats / percentage.
extern const char* SESSION_STATS_SQL;
