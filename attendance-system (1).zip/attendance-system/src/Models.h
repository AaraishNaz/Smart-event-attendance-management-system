// Models.h - model classes. Each one knows how to build itself from a JSON request
// and VALIDATE itself (throws ValidationError). Repositories only ever store valid models.
#pragma once
#include "Database.h"

namespace val {   // small validation helpers
std::string trim(const std::string& s);
std::string upper(std::string s);
std::string reqStr(const json& b, const char* key);
std::string optStr(const json& b, const char* key);
int  reqInt(const json& b, const char* key);
int  optInt(const json& b, const char* key, int def = 0);
std::string reqDate(const json& b, const char* key);      // YYYY-MM-DD
std::string reqDateTime(const json& b, const char* key);  // YYYY-MM-DD HH:MM  ('T' separator accepted)
}

struct Event {
    int id = 0;
    std::string name, location, startDate, endDate, description;
    std::vector<std::string> topics;
    static Event fromRequest(const json& body);
};

struct Session {
    int id = 0, eventId = 0, topicId = 0 /* 0 = none */, capacity = 0;
    std::string title, room, startTime, endTime;
    static Session fromRequest(const json& body);
};

struct Attendee {
    int id = 0;
    std::string code, qr, name, email, phone, organization;
    static Attendee fromRequest(const json& body);
};
