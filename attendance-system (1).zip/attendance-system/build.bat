@echo off
REM Build with MinGW-w64 (MSYS2 UCRT64 g++ must be on PATH). Run from the project root.
cmake -S . -B build -G "MinGW Makefiles" -DCMAKE_BUILD_TYPE=Release || exit /b 1
cmake --build build -j || exit /b 1
echo.
echo Build finished.  Run tests:   build\run_tests.exe
echo                  Start server: build\attendance_server.exe   then open http://localhost:8080
