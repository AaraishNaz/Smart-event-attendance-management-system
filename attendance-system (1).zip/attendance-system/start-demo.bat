@echo off
REM Double-click this file (kept inside the attendance-system project folder) to start the demo.
cd /d "%~dp0"
if not exist "build\Release\attendance_server.exe" (
  echo attendance_server.exe not found in build\Release. Build the project first.
  pause
  exit /b 1
)
start "Attendance Server (do not close)" cmd /k "build\Release\attendance_server.exe"
timeout /t 3 /nobreak >nul
start "" chrome "http://localhost:8080"
start "" chrome --incognito "http://localhost:8080"
