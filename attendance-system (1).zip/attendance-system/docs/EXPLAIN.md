# How to explain this project (Phase 3 cheat sheet)

## 30-second pitch
"Normal attendance only records entry to the venue. Our system puts a **check-in kiosk in every session room**.
A scan (QR from a USB scanner, or a typed ID) goes into a **thread-safe queue**; **worker threads** take scans out,
and for each one run **one SQLite transaction** that checks attendee, duplicate and capacity and then inserts the attendance.
Because that check+insert is atomic, simultaneous scans can never overbook a session or record someone twice.
The web dashboard reads live numbers from the database through our C++ REST API."

## Architecture
```
 Browser (HTML/CSS/JS)
      |  HTTP + JSON
      v
 cpp-httplib server (thread pool) ---- CRUD / reports / dashboard ----> own SQLite connection per thread
      |
      | POST /api/checkin  (HTTP thread = PRODUCER)
      v
 +------------------------------+
 | ScanQueue  (mutex + condvar) |      <- shared component
 +------------------------------+
      |  pop()                 (workers = CONSUMERS, each with its OWN SQLite connection)
      v
 Worker 1 .. Worker N --> AttendanceEngine::checkIn --> attendance.db  (WAL mode)
      |
      +--> std::promise.set_value(result) --> the waiting HTTP thread / kiosk gets its std::future
```

## One scan, step by step (`AttendanceEngine.cpp`)
1. Kiosk sends `code` + `session_id`; code is trimmed and upper-cased (scanners add Enter).
2. `BEGIN IMMEDIATE` - this worker now holds the database write lock.
3. Session exists? -> else `UNKNOWN_SESSION`.  Attendee with that QR or ID? -> else `UNKNOWN_ATTENDEE`.
4. Already in `attendance`? -> `DUPLICATE`.  `COUNT(*) >= capacity`? -> `SESSION_FULL`.
5. `INSERT INTO attendance`; also `INSERT INTO scan_log` (every scan is logged); `COMMIT`.
6. Any SQLite error -> rollback (RAII class `Tx`) and `DATABASE_ERROR`.

## Where each OS concept lives
| Concept | Where | Why |
|---|---|---|
| `std::thread` | `Pipeline.cpp` (workers), `Workload.cpp` (kiosks) | parallel producers and consumers |
| `std::mutex` + `std::unique_lock` | `ScanQueue.h` | only one thread touches the `std::queue` at a time |
| `std::condition_variable` | `ScanQueue.h` | workers sleep (no busy waiting) until a scan arrives or the queue closes |
| `std::atomic` | `Pipeline.h` counters, start flag in `Workload.cpp` | lock-free counters / "go" signal |
| `std::promise/future` | `Pipeline.cpp` | hand the result back to the producer |
| Safe termination | `ScanQueue::close()`, `Pipeline::shutdown()` | close = no new work, workers **drain** the rest, then exit and are joined -> no lost scans |
| Race condition demo | `Workload.cpp::runUnsafe` vs `runWorkload` | shows overbooking when synchronization is missing |

## How SQLite connections are managed (required explanation)
* A SQLite connection is **never shared between threads**. Every worker thread opens its own `Database` object (`Pipeline::workerLoop`),
  and every HTTP thread uses a `thread_local` connection (`conn()` in `main.cpp`).
* All connections use **WAL mode**: readers (dashboard) do not block the writer, and there is one writer at a time.
* `busy_timeout` = 15 s: a worker that finds the write lock taken waits instead of failing.
* `BEGIN IMMEDIATE` takes the write lock **before** reading the count, so "count < capacity" cannot become stale before the insert.
  (A plain `BEGIN` would let two workers read the same count and both insert = the exact bug of the unsafe demo.)
* Second safety net: `UNIQUE(attendee_id, session_id)` - even a bug in C++ could not store the same attendance twice.
* `PRAGMA foreign_keys=ON` on every connection (SQLite has it off by default).

## Database (5 required tables + extras)
`events -> topics`, `events -> sessions -> attendance <- attendees`.
Extras: `scan_log` (audit of every scan), view `v_session_stats` (occupancy, used by dashboard and reports).
Indexes on every foreign key and on `scan_log(session_id,result)`. Deleting is refused when attendance exists.

## Demo script for tomorrow (about 8 minutes)
1. `build\run_tests.exe` - show all green, point out the 4-workload table (scans, success, duplicates, time, throughput, integrity).
2. Start `attendance_server.exe`, open `http://localhost:8080` - **Dashboard**: cards, chart, progress bars (numbers come from SQLite).
3. **Check-in Kiosk**: pick "Lab 1", type `ATT-0030` -> SUCCESS; again -> DUPLICATE; type `ATT-9999` -> UNKNOWN_ATTENDEE.
4. Pick the smallest session, click "Simulate random scan" repeatedly until **SESSION_FULL** (capacity enforcement).
5. Back to the Dashboard - the numbers changed by themselves (5 s auto-refresh).
6. **Reports**: switch report type, click *Download CSV*, click *Verify database integrity*.
7. **Concurrency Lab**: "Run demonstration" - SAFE = exactly 10/10, UNSAFE = more than 10 and duplicates.
8. Show `AttendanceEngine.cpp` (the 40-line transaction) and `ScanQueue.h` (the 50-line queue).

## Likely questions
**Why a queue instead of letting every kiosk write to the DB?** It decouples fast producers from the DB, limits DB writers to N workers, and gives one place for orderly shutdown.
**Why `condition_variable` and not a loop?** A loop would burn CPU; the condition variable puts workers to sleep until work arrives.
**Why the predicate in `cv.wait`?** Protects against spurious wake-ups and a missed notification.
**How do you stop without losing scans?** `close()` stops new pushes; `pop()` still returns queued items; it returns false only when closed **and** empty, then workers exit and are joined.
**What prevents overbooking?** Count check + insert inside one `BEGIN IMMEDIATE` transaction; only one worker can be inside at a time.
**What prevents duplicates?** The duplicate check in the same transaction, plus the UNIQUE constraint as a safety net.
**Is the unsafe demo dangerous for real data?** No - it creates a temporary database file in the OS temp folder and deletes it afterwards.
**Why per-thread connections?** SQLite connections are not meant to be used from two threads at once without extra locking; separate connections let SQLite's file locking do the coordination.
**Does it scan QR codes with a camera?** No. A USB scanner behaves like a keyboard (types the code + Enter), and IDs can be typed. Camera scanning would be future work.
**What is the `scan_log` table for?** Duplicate statistics need the rejected scans too; `attendance` only holds successful ones.
**Throughput limits?** SQLite allows one writer at a time, so more workers do not scale write speed linearly; the stress table shows this honestly.
**Possible improvements:** camera QR via JS library, authentication for the API, per-event attendee registration, WebSocket live updates.


## GEHU demo extension: identity, rotating QR and class synchronization

- **Authentication / DBMS:** `app_users` stores role-linked demo identities and PBKDF2 password hashes; `auth_sessions` stores random expiring login tokens. The browser receives an HttpOnly, SameSite cookie. API routing checks the session before protected routes, and individual routes enforce admin/organizer/student responsibilities.
- **Event approval:** `event_approvals` holds PENDING / APPROVED / REJECTED status. An organizer-created event remains pending until an administrator approves it. The live QR endpoint refuses pending events.
- **Dynamic QR:** `qr_tokens` stores a random challenge tied to one session and expiring after three seconds. The organizer display requests a fresh token every three seconds. A student must be signed in and submit the current challenge; the server resolves the student identity from the login session rather than trusting a student ID in the request.
- **Class synchronization:** on successful approved-event check-in, the server finds class slots that overlap the event session and match the student's batch. It writes `PRESENT_VIA_APPROVED_EVENT`, linking the class record to the event. This is an auditable authorized-activity state, not a claim of physical classroom presence.
- **OS / DBMS boundary:** the HTTP request submits a scan to the producer-consumer pipeline; worker threads process it; SQLite transactions and unique constraints protect records. The event QR challenge and role session are validated before the attendance pipeline is invoked.
- **Demo limitations:** the project uses local demo identities and SQLite. It is not connected to GEHU's production ERP, student directory, timetable or SSO. A live QR can still be relayed within its 3-second lifetime; the rotating challenge is a mitigation, not complete anti-proxy proof.
