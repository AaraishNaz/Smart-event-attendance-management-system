#include "Database.h"

Database::Database(const std::string& path) {
    int rc = sqlite3_open_v2(path.c_str(), &db_,
                             SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE | SQLITE_OPEN_FULLMUTEX, nullptr);
    if (rc != SQLITE_OK) {
        std::string m = db_ ? sqlite3_errmsg(db_) : "cannot open database";
        if (db_) sqlite3_close(db_);
        db_ = nullptr;
        throw DbError("open " + path + ": " + m, rc);
    }
    sqlite3_extended_result_codes(db_, 1);   // e.g. 2067 = UNIQUE constraint failed
    sqlite3_busy_timeout(db_, 15000);        // wait up to 15 s if another connection holds the write lock
    exec("PRAGMA foreign_keys = ON;");       // FK enforcement is OFF by default in SQLite!
    exec("PRAGMA journal_mode = WAL;");      // readers do not block the single writer
    exec("PRAGMA synchronous = NORMAL;");
}

Database::~Database() {
    rollback();
    if (db_) sqlite3_close(db_);
}

void Database::fail(const char* ctx, sqlite3_stmt* st) {
    int code = sqlite3_extended_errcode(db_);
    std::string msg = std::string(ctx) + ": " + sqlite3_errmsg(db_);
    if (st) sqlite3_finalize(st);
    throw DbError(msg, code);
}

void Database::exec(const std::string& sql) {
    char* err = nullptr;
    if (sqlite3_exec(db_, sql.c_str(), nullptr, nullptr, &err) != SQLITE_OK) {
        std::string m = err ? err : "exec failed";
        sqlite3_free(err);
        throw DbError(m, sqlite3_extended_errcode(db_));
    }
}

static void bindAll(sqlite3_stmt* st, const std::vector<json>& p) {
    for (size_t i = 0; i < p.size(); ++i) {
        int idx = static_cast<int>(i) + 1;
        const json& v = p[i];
        if (v.is_null())                 sqlite3_bind_null(st, idx);
        else if (v.is_boolean())         sqlite3_bind_int(st, idx, v.get<bool>() ? 1 : 0);
        else if (v.is_number_integer())  sqlite3_bind_int64(st, idx, v.get<long long>());
        else if (v.is_number())          sqlite3_bind_double(st, idx, v.get<double>());
        else {
            std::string s = v.is_string() ? v.get<std::string>() : v.dump();
            sqlite3_bind_text(st, idx, s.c_str(), static_cast<int>(s.size()), SQLITE_TRANSIENT);
        }
    }
}

json Database::query(const std::string& sql, const std::vector<json>& p) {
    sqlite3_stmt* st = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &st, nullptr) != SQLITE_OK) fail("prepare", st);
    bindAll(st, p);
    json rows = json::array();
    int rc;
    while ((rc = sqlite3_step(st)) == SQLITE_ROW) {
        json row = json::object();
        for (int c = 0; c < sqlite3_column_count(st); ++c) {
            const char* name = sqlite3_column_name(st, c);
            switch (sqlite3_column_type(st, c)) {
                case SQLITE_INTEGER: row[name] = static_cast<long long>(sqlite3_column_int64(st, c)); break;
                case SQLITE_FLOAT:   row[name] = sqlite3_column_double(st, c); break;
                case SQLITE_NULL:    row[name] = nullptr; break;
                default: row[name] = std::string(reinterpret_cast<const char*>(sqlite3_column_text(st, c)));
            }
        }
        rows.push_back(std::move(row));
    }
    if (rc != SQLITE_DONE) fail("step", st);
    sqlite3_finalize(st);
    return rows;
}

int Database::run(const std::string& sql, const std::vector<json>& p) {
    sqlite3_stmt* st = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &st, nullptr) != SQLITE_OK) fail("prepare", st);
    bindAll(st, p);
    int rc = sqlite3_step(st);
    while (rc == SQLITE_ROW) rc = sqlite3_step(st);   // ignore any rows (e.g. RETURNING)
    if (rc != SQLITE_DONE) fail("step", st);
    sqlite3_finalize(st);
    return sqlite3_changes(db_);
}

void Database::begin(bool immediate) {
    if (inTx_) throw DbError("nested transaction", -1);
    exec(immediate ? "BEGIN IMMEDIATE" : "BEGIN");
    inTx_ = true;
}
void Database::commit() { exec("COMMIT"); inTx_ = false; }
void Database::rollback() noexcept {
    if (inTx_) { sqlite3_exec(db_, "ROLLBACK", nullptr, nullptr, nullptr); inTx_ = false; }
}
